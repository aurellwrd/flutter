class AppConfig {
  static String baseUrl = "https://capekngoding.com";
  static String token = "";
}
