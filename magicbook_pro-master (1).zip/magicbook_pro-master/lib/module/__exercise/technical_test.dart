// ignore_for_file: dead_code, unused_local_variable, unnecessary_null_comparison

class TechnicalTest {
  static dynamic output;
  List list = [
    // Exercise 1
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data int dan beri nilai 10
      // >>> Tulis jawabanmu di bawah ini
      int output = 3;
      // --- End of Answer ---

      return output == 10;
    },
    // Exercise 2
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data int dan beri nilai 42
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is int && output == 42;
    },
    // Exercise 3
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data int dan beri nilai -7
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is int && output == -7;
    },
    // Exercise 4
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data int dan beri nilai 0
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is int && output == 0;
    },
    // Exercise 5
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data int dan beri nilai 99999
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is int && output == 99999;
    },
    // Exercise 6
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data int dan beri nilai -12345
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is int && output == -12345;
    },
    // Exercise 7
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data int dan beri nilai 1000000
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is int && output == 1000000;
    },
    // Exercise 8
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data int dan beri nilai -987654
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is int && output == -987654;
    },
    // Exercise 9
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data int dan beri nilai 888
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is int && output == 888;
    },
    // Exercise 10
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data int dan beri nilai -555
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is int && output == -555;
    },
    // Exercise 11
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data double dan beri nilai 3.14
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is double && output == 3.14;
    },
    // Exercise 12
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data double dan beri nilai 2.71828
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is double && output == 2.71828;
    },
    // Exercise 13
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data double dan beri nilai -5.67
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is double && output == -5.67;
    },
    // Exercise 14
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data double dan beri nilai 0.0
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is double && output == 0.0;
    },
    // Exercise 15
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data double dan beri nilai 12345.6789
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is double && output == 12345.6789;
    },
    // Exercise 16
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data double dan beri nilai 7.5
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is double && output == 7.5;
    },
    // Exercise 17
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data double dan beri nilai -2.25
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is double && output == -2.25;
    },
    // Exercise 18
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data double dan beri nilai 0.01
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is double && output == 0.01;
    },
    // Exercise 19
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data double dan beri nilai 123.456
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is double && output == 123.456;
    },
    // Exercise 20
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data double dan beri nilai -9876.54321
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is double && output == -9876.54321;
    },
    // Exercise 21
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data boolean dan beri nilai true
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is bool && output == true;
    },
    // Exercise 22
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data boolean dan beri nilai false
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is bool && output == false;
    },
    // Exercise 23
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data boolean dan beri nilai true
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is bool && output == true;
    },
    // Exercise 24
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data boolean dan beri nilai false
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is bool && output == false;
    },
    // Exercise 25
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data boolean dan beri nilai true
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is bool && output == true;
    },
    // Exercise 26
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data boolean dan beri nilai false
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is bool && output == false;
    },
    // Exercise 27
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data boolean dan beri nilai true
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is bool && output == true;
    },
    // Exercise 28
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data boolean dan beri nilai false
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is bool && output == false;
    },
    // Exercise 29
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data boolean dan beri nilai true
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is bool && output == true;
    },
    // Exercise 30
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data boolean dan beri nilai false
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is bool && output == false;
    },
    // Exercise 31
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data String dan beri nilai "Hello, World!"
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "Hello, World!";
    },
    // Exercise 32
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data String dan beri nilai "Dart is fun!"
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "Dart is fun!";
    },
    // Exercise 33
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data String dan beri nilai "12345"
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "12345";
    },
    // Exercise 34
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data String dan beri nilai "3.14159"
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "3.14159";
    },
    // Exercise 35
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data String dan beri nilai "true"
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "true";
    },
    // Exercise 36
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data String dan beri nilai "false"
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "false";
    },
    // Exercise 37
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data String dan beri nilai "Hello, Dart!"
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "Hello, Dart!";
    },
    // Exercise 38
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data String dan beri nilai "42"
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "42";
    },
    // Exercise 39
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data String dan beri nilai "3.14"
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "3.14";
    },
    // Exercise 40
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data String dan beri nilai "Hello, World!"
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "Hello, World!";
    },
    // Exercise 41
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data DateTime dan beri nilai tanggal 1 Januari 2022
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is DateTime &&
          output.year == 2022 &&
          output.month == 1 &&
          output.day == 1;
    },
    // Exercise 42
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data DateTime dan beri nilai tanggal 31 Desember 2000
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is DateTime &&
          output.year == 2000 &&
          output.month == 12 &&
          output.day == 31;
    },
    // Exercise 43
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data DateTime dan beri nilai tanggal 15 September 1995
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is DateTime &&
          output.year == 1995 &&
          output.month == 9 &&
          output.day == 15;
    },
    // Exercise 44
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data DateTime dan beri nilai tanggal 10 Mei 2023
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is DateTime &&
          output.year == 2023 &&
          output.month == 5 &&
          output.day == 10;
    },
    // Exercise 45
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data DateTime dan beri nilai tanggal 24 November 2010
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is DateTime &&
          output.year == 2010 &&
          output.month == 11 &&
          output.day == 24;
    },
    // Exercise 46
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<int> dan beri nilai [1, 2, 3, 4, 5]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<int> &&
          output.length == 5 &&
          output[0] == 1 &&
          output[4] == 5;
    },
    // Exercise 47
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<int> dan beri nilai [10, 20, 30, 40, 50]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<int> &&
          output.length == 5 &&
          output[0] == 10 &&
          output[4] == 50;
    },
    // Exercise 48
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<int> dan beri nilai [5, 4, 3, 2, 1]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<int> &&
          output.length == 5 &&
          output[0] == 5 &&
          output[4] == 1;
    },
    // Exercise 49
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<int> dan beri nilai [0, 2, 4, 6, 8]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<int> &&
          output.length == 5 &&
          output[0] == 0 &&
          output[4] == 8;
    },
    // Exercise 50
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<int> dan beri nilai [9, 7, 5, 3, 1]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<int> &&
          output.length == 5 &&
          output[0] == 9 &&
          output[4] == 1;
    },
    // Exercise 51
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<double> dan beri nilai [1.1, 2.2, 3.3, 4.4, 5.5]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<double> &&
          output.length == 5 &&
          output[0] == 1.1 &&
          output[4] == 5.5;
    },
    // Exercise 52
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<double> dan beri nilai [0.5, 1.5, 2.5, 3.5, 4.5]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<double> &&
          output.length == 5 &&
          output[0] == 0.5 &&
          output[4] == 4.5;
    },
    // Exercise 53
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<double> dan beri nilai [10.0, 20.0, 30.0, 40.0, 50.0]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<double> &&
          output.length == 5 &&
          output[0] == 10.0 &&
          output[4] == 50.0;
    },
    // Exercise 54
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<String> dan beri nilai ["apple", "banana", "cherry", "date", "fig"]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.length == 5 &&
          output[0] == "apple" &&
          output[4] == "fig";
    },
    // Exercise 55
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<String> dan beri nilai ["grape", "kiwi", "lemon", "mango", "orange"]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.length == 5 &&
          output[0] == "grape" &&
          output[4] == "orange";
    },
    // Exercise 56
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<String> dan beri nilai ["pear", "quince", "raspberry", "strawberry", "tangerine"]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.length == 5 &&
          output[0] == "pear" &&
          output[4] == "tangerine";
    },
    // Exercise 57
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<bool> dan beri nilai [true, false, true, false, true]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<bool> &&
          output.length == 5 &&
          output[0] == true &&
          output[4] == true;
    },
    // Exercise 58
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<bool> dan beri nilai [false, true, false, true, false]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<bool> &&
          output.length == 5 &&
          output[0] == false &&
          output[4] == false;
    },
    // Exercise 59
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "Alice", "age": 30},
      //   {"name": "Bob", "age": 25},
      //   {"name": "Carol", "age": 35},
      //   {"name": "David", "age": 28},
      //   {"name": "Eve", "age": 22}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<Map<String, dynamic>> &&
          output.length == 5 &&
          output[0]["name"] == "Alice" &&
          output[0]["age"] == 30 &&
          output[4]["name"] == "Eve" &&
          output[4]["age"] == 22;
    },
    // Exercise 60
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"fruit": "apple", "color": "red"},
      //   {"fruit": "banana", "color": "yellow"},
      //   {"fruit": "cherry", "color": "red"},
      //   {"fruit": "date", "color": "brown"},
      //   {"fruit": "fig", "color": "purple"}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<Map<String, dynamic>> &&
          output.length == 5 &&
          output[0]["fruit"] == "apple" &&
          output[0]["color"] == "red" &&
          output[4]["fruit"] == "fig" &&
          output[4]["color"] == "purple";
    },
    // Exercise 61
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "Alice", "scores": [85, 90, 78]},
      //   {"name": "Bob", "scores": [92, 88, 95]},
      //   {"name": "Carol", "scores": [78, 85, 80]},
      //   {"name": "David", "scores": [90, 87, 92]},
      //   {"name": "Eve", "scores": [75, 82, 80]}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<Map<String, dynamic>> &&
          output.length == 5 &&
          output[0]["name"] == "Alice" &&
          output[0]["scores"].length == 3 &&
          output[4]["name"] == "Eve" &&
          output[4]["scores"].length == 3;
    },
    // Exercise 62
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "Alice", "skills": ["Java", "Python", "C++"]},
      //   {"name": "Bob", "skills": ["Python", "JavaScript", "Ruby"]},
      //   {"name": "Carol", "skills": ["JavaScript", "HTML", "CSS"]},
      //   {"name": "David", "skills": ["Java", "C#", "PHP"]},
      //   {"name": "Eve", "skills": ["Ruby", "Python", "Java"]}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<Map<String, dynamic>> &&
          output.length == 5 &&
          output[0]["name"] == "Alice" &&
          output[0]["skills"].length == 3 &&
          output[4]["name"] == "Eve" &&
          output[4]["skills"].length == 3;
    },
    // Exercise 63
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "Alice", "courses": ["Math", "Physics"]},
      //   {"name": "Bob", "courses": ["Biology", "Chemistry"]},
      //   {"name": "Carol", "courses": ["English", "History"]},
      //   {"name": "David", "courses": ["Computer Science", "Programming"]},
      //   {"name": "Eve", "courses": ["Geography", "Economics"]}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<Map<String, dynamic>> &&
          output.length == 5 &&
          output[0]["name"] == "Alice" &&
          output[0]["courses"].length == 2 &&
          output[4]["name"] == "Eve" &&
          output[4]["courses"].length == 2;
    },
    // Exercise 64
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "Alice", "data": {"age": 30, "city": "New York"}},
      //   {"name": "Bob", "data": {"age": 25, "city": "Los Angeles"}},
      //   {"name": "Carol", "data": {"age": 35, "city": "Chicago"}},
      //   {"name": "David", "data": {"age": 28, "city": "Houston"}},
      //   {"name": "Eve", "data": {"age": 22, "city": "Miami"}}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<Map<String, dynamic>> &&
          output.length == 5 &&
          output[0]["name"] == "Alice" &&
          output[0]["data"]["age"] == 30 &&
          output[0]["data"]["city"] == "New York" &&
          output[4]["name"] == "Eve" &&
          output[4]["data"]["age"] == 22 &&
          output[4]["data"]["city"] == "Miami";
    },
    // Exercise 65
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "Alice", "details": {"age": 30, "city": "New York", "occupation": "Engineer"}},
      //   {"name": "Bob", "details": {"age": 25, "city": "Los Angeles", "occupation": "Designer"}},
      //   {"name": "Carol", "details": {"age": 35, "city": "Chicago", "occupation": "Teacher"}},
      //   {"name": "David", "details": {"age": 28, "city": "Houston", "occupation": "Developer"}},
      //   {"name": "Eve", "details": {"age": 22, "city": "Miami", "occupation": "Student"}}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<Map<String, dynamic>> &&
          output.length == 5 &&
          output[0]["name"] == "Alice" &&
          output[0]["details"]["age"] == 30 &&
          output[0]["details"]["city"] == "New York" &&
          output[4]["name"] == "Eve" &&
          output[4]["details"]["age"] == 22 &&
          output[4]["details"]["city"] == "Miami";
    },
    // Exercise 66
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data Map<String, dynamic> dan beri nilai sesuai contoh berikut:
      // {
      //   "name": "Alice",
      //   "details": {
      //     "age": 30,
      //     "city": "New York"
      //   }
      // }
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is Map<String, dynamic> &&
          output["name"] == "Alice" &&
          output["details"]["age"] == 30 &&
          output["details"]["city"] == "New York";
    },
    // Exercise 67
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data Map<String, dynamic> dan beri nilai sesuai contoh berikut:
      // {
      //   "name": "Bob",
      //   "details": {
      //     "age": 25,
      //     "city": "Los Angeles"
      //   }
      // }
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is Map<String, dynamic> &&
          output["name"] == "Bob" &&
          output["details"]["age"] == 25 &&
          output["details"]["city"] == "Los Angeles";
    },
    // Exercise 68
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data Map<String, dynamic> dan beri nilai sesuai contoh berikut:
      // {
      //   "name": "Carol",
      //   "details": {
      //     "age": 35,
      //     "city": "Chicago"
      //   }
      // }
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is Map<String, dynamic> &&
          output["name"] == "Carol" &&
          output["details"]["age"] == 35 &&
          output["details"]["city"] == "Chicago";
    },
    // Exercise 69
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data Map<String, dynamic> dan beri nilai sesuai contoh berikut:
      // {
      //   "name": "David",
      //   "details": {
      //     "age": 28,
      //     "city": "Houston"
      //   }
      // }
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is Map<String, dynamic> &&
          output["name"] == "David" &&
          output["details"]["age"] == 28 &&
          output["details"]["city"] == "Houston";
    },
    // Exercise 70
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data Map<String, dynamic> dan beri nilai sesuai contoh berikut:
      // {
      //   "name": "Eve",
      //   "details": {
      //     "age": 22,
      //     "city": "Miami"
      //   }
      // }
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is Map<String, dynamic> &&
          output["name"] == "Eve" &&
          output["details"]["age"] == 22 &&
          output["details"]["city"] == "Miami";
    },
    // Exercise 71
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "Alice", "age": 30},
      //   {"name": "Bob", "age": 25},
      //   {"name": "Carol", "age": 35}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output[0]["name"] == "Alice" &&
          output[0]["age"] == 30 &&
          output[1]["name"] == "Bob" &&
          output[1]["age"] == 25 &&
          output[2]["name"] == "Carol" &&
          output[2]["age"] == 35;
    },
    // Exercise 72
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "David", "age": 28},
      //   {"name": "Eve", "age": 22},
      //   {"name": "Frank", "age": 40}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output[0]["name"] == "David" &&
          output[0]["age"] == 28 &&
          output[1]["name"] == "Eve" &&
          output[1]["age"] == 22 &&
          output[2]["name"] == "Frank" &&
          output[2]["age"] == 40;
    },
    // Exercise 73
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "Grace", "age": 50},
      //   {"name": "Hank", "age": 45},
      //   {"name": "Ivy", "age": 29}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output[0]["name"] == "Grace" &&
          output[0]["age"] == 50 &&
          output[1]["name"] == "Hank" &&
          output[1]["age"] == 45 &&
          output[2]["name"] == "Ivy" &&
          output[2]["age"] == 29;
    },
    // Exercise 74
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "Jack", "age": 33},
      //   {"name": "Kate", "age": 27},
      //   {"name": "Leo", "age": 38}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output[0]["name"] == "Jack" &&
          output[0]["age"] == 33 &&
          output[1]["name"] == "Kate" &&
          output[1]["age"] == 27 &&
          output[2]["name"] == "Leo" &&
          output[2]["age"] == 38;
    },
    // Exercise 75
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "Mia", "age": 24},
      //   {"name": "Noah", "age": 29},
      //   {"name": "Olivia", "age": 26}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output[0]["name"] == "Mia" &&
          output[0]["age"] == 24 &&
          output[1]["name"] == "Noah" &&
          output[1]["age"] == 29 &&
          output[2]["name"] == "Olivia" &&
          output[2]["age"] == 26;
    },
    // Exercise 76
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "Peter", "age": 31},
      //   {"name": "Queen", "age": 23},
      //   {"name": "Robert", "age": 36}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output[0]["name"] == "Peter" &&
          output[0]["age"] == 31 &&
          output[1]["name"] == "Queen" &&
          output[1]["age"] == 23 &&
          output[2]["name"] == "Robert" &&
          output[2]["age"] == 36;
    },
    // Exercise 77
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "Sam", "age": 27},
      //   {"name": "Tom", "age": 32},
      //   {"name": "Uma", "age": 30}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output[0]["name"] == "Sam" &&
          output[0]["age"] == 27 &&
          output[1]["name"] == "Tom" &&
          output[1]["age"] == 32 &&
          output[2]["name"] == "Uma" &&
          output[2]["age"] == 30;
    },
    // Exercise 78
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "Victoria", "age": 29},
      //   {"name": "William", "age": 24},
      //   {"name": "Xander", "age": 35}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output[0]["name"] == "Victoria" &&
          output[0]["age"] == 29 &&
          output[1]["name"] == "William" &&
          output[1]["age"] == 24 &&
          output[2]["name"] == "Xander" &&
          output[2]["age"] == 35;
    },
    // Exercise 79
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "Yara", "age": 28},
      //   {"name": "Zane", "age": 31}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output[0]["name"] == "Yara" &&
          output[0]["age"] == 28 &&
          output[1]["name"] == "Zane" &&
          output[1]["age"] == 31;
    },
    // Exercise 80
    () {
      // ? Instruksi: Deklarasikan sebuah variabel "output" dengan tipe data List<Map<String, dynamic>> dan beri nilai sesuai contoh berikut:
      // [
      //   {"name": "Alice", "age": 30},
      //   {"name": "Bob", "age": 25},
      //   {"name": "Carol", "age": 35},
      //   {"name": "David", "age": 28},
      //   {"name": "Eve", "age": 22},
      //   {"name": "Frank", "age": 40},
      //   {"name": "Grace", "age": 50},
      //   {"name": "Hank", "age": 45},
      //   {"name": "Ivy", "age": 29},
      //   {"name": "Jack", "age": 33},
      //   {"name": "Kate", "age": 27},
      //   {"name": "Leo", "age": 38},
      //   {"name": "Mia", "age": 24},
      //   {"name": "Noah", "age": 29},
      //   {"name": "Olivia", "age": 26},
      //   {"name": "Peter", "age": 31},
      //   {"name": "Queen", "age": 23},
      //   {"name": "Robert", "age": 36},
      //   {"name": "Sam", "age": 27},
      //   {"name": "Tom", "age": 32},
      //   {"name": "Uma", "age": 30},
      //   {"name": "Victoria", "age": 29},
      //   {"name": "William", "age": 24},
      //   {"name": "Xander", "age": 35},
      //   {"name": "Yara", "age": 28},
      //   {"name": "Zane", "age": 31}
      // ]
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output.length == 26 &&
          output[2]["name"] == "Carol" &&
          output.last["age"] == 31;
    },
    // Exercise 81
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "42"
      // ? Instruksi 2: Buatlah variabel int? output;
      // ? Instruksi 3: Konversi input menjadi integer dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is int && output == 42;
    },
    // Exercise 82
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "0"
      // ? Instruksi 2: Buatlah variabel int? output;
      // ? Instruksi 3: Konversi input menjadi integer dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is int && output == 0;
    },
    // Exercise 83
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "-99"
      // ? Instruksi 2: Buatlah variabel int? output;
      // ? Instruksi 3: Konversi input menjadi integer dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is int && output == -99;
    },
    // Exercise 84
    () {
      // ? Instruksi 1: Buatlah variabel double input dengan nilai "3.14"
      // ? Instruksi 2: Buatlah variabel int? output;
      // ? Instruksi 3: Konversi input menjadi integer dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is int && output == 3;
    },
    // Exercise 85
    () {
      // ? Instruksi 1: Buatlah variabel double input dengan nilai "9.99"
      // ? Instruksi 2: Buatlah variabel int? output;
      // ? Instruksi 3: Konversi input menjadi integer dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is int && output == 9;
    },
    // Exercise 86
    () {
      // ? Instruksi 1: Buatlah variabel double input dengan nilai "5.5"
      // ? Instruksi 2: Buatlah variabel int? output;
      // ? Instruksi 3: Konversi input menjadi integer dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is int && output == 5;
    },
    // Exercise 87
    () {
      // ? Instruksi 1: Buatlah variabel bool input dengan nilai true
      // ? Instruksi 2: Buatlah variabel int? output;
      // ? Instruksi 3: Konversi input menjadi integer dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is int && output == 1;
    },
    // Exercise 88
    () {
      // ? Instruksi 1: Buatlah variabel bool input dengan nilai false
      // ? Instruksi 2: Buatlah variabel int? output;
      // ? Instruksi 3: Konversi input menjadi integer dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is int && output == 0;
    },
    // Exercise 89
    () {
      // ? Instruksi 1: Buatlah variabel bool input dengan nilai true
      // ? Instruksi 2: Buatlah variabel int? output;
      // ? Instruksi 3: Konversi input menjadi integer dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is int && output == 1;
    },
    // Exercise 90
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "123"
      // ? Instruksi 2: Buatlah variabel int? output;
      // ? Instruksi 3: Konversi input menjadi integer dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is int && output == 123;
    },
    // Exercise 91
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "3.14"
      // ? Instruksi 2: Buatlah variabel double? output;
      // ? Instruksi 3: Konversi input menjadi double dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is double && output == 3.14;
    },
    // Exercise 92
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "9.99"
      // ? Instruksi 2: Buatlah variabel double? output;
      // ? Instruksi 3: Konversi input menjadi double dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is double && output == 9.99;
    },
    // Exercise 93
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "5.5"
      // ? Instruksi 2: Buatlah variabel double? output;
      // ? Instruksi 3: Konversi input menjadi double dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is double && output == 5.5;
    },
    // Exercise 94
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "true"
      // ? Instruksi 2: Buatlah variabel bool? output;
      // ? Instruksi 3: Konversi input menjadi boolean dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is bool && output == true;
    },
    // Exercise 95
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "false"
      // ? Instruksi 2: Buatlah variabel bool? output;
      // ? Instruksi 3: Konversi input menjadi boolean dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is bool && output == false;
    },
    // Exercise 96
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "0"
      // ? Instruksi 2: Buatlah variabel bool? output;
      // ? Instruksi 3: Konversi input menjadi boolean dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is bool && output == false;
    },
    // Exercise 97
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "Hello, World!"
      // ? Instruksi 2: Buatlah variabel String? output;
      // ? Instruksi 3: Konversi input menjadi String dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is String && output == "Hello, World!";
    },
    // Exercise 98
    () {
      // ? Instruksi 1: Buatlah variabel int input dengan nilai 2022
      // ? Instruksi 2: Buatlah variabel String? output;
      // ? Instruksi 3: Konversi input menjadi String dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is String && output == "2022";
    },
    // Exercise 99
    () {
      // ? Instruksi 1: Buatlah variabel double input dengan nilai 3.14159
      // ? Instruksi 2: Buatlah variabel String? output;
      // ? Instruksi 3: Konversi input menjadi String dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is String && output == "3.14159";
    },
    // Exercise 100
    () {
      // ? Instruksi 1: Buatlah variabel DateTime input dengan tanggal 2023-08-09
      // ? Instruksi 2: Buatlah variabel String? output;
      // ? Instruksi 3: Konversi input menjadi String dengan format "yyyy-MM-dd" dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is String && output == "2023-08-09";
    },
    // Exercise 101
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "true"
      // ? Instruksi 2: Buatlah variabel bool? output;
      // ? Instruksi 3: Konversi input menjadi boolean dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is bool && output == true;
    },
    // Exercise 102
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "false"
      // ? Instruksi 2: Buatlah variabel bool? output;
      // ? Instruksi 3: Konversi input menjadi boolean dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is bool && output == false;
    },
    // Exercise 103
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "0"
      // ? Instruksi 2: Buatlah variabel bool? output;
      // ? Instruksi 3: Konversi input menjadi boolean dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is bool && output == false;
    },
    // Exercise 104
    () {
      // ? Instruksi 1: Buatlah variabel bool input dengan nilai true
      // ? Instruksi 2: Buatlah variabel String? output;
      // ? Instruksi 3: Konversi input menjadi String dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is String && output == "true";
    },
    // Exercise 105
    () {
      // ? Instruksi 1: Buatlah variabel bool input dengan nilai false
      // ? Instruksi 2: Buatlah variabel String? output;
      // ? Instruksi 3: Konversi input menjadi String dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is String && output == "false";
    },
    // Exercise 106
    () {
      // ? Instruksi 1: Buatlah variabel int input dengan nilai 42
      // ? Instruksi 2: Buatlah variabel String? output;
      // ? Instruksi 3: Konversi input menjadi String dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is String && output == "42";
    },
    // Exercise 107
    () {
      // ? Instruksi 1: Buatlah variabel double input dengan nilai 3.14
      // ? Instruksi 2: Buatlah variabel String? output;
      // ? Instruksi 3: Konversi input menjadi String dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is String && output == "3.14";
    },
    // Exercise 108
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "9.99"
      // ? Instruksi 2: Buatlah variabel double? output;
      // ? Instruksi 3: Konversi input menjadi double dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is double && output == 9.99;
    },
    // Exercise 109
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "3.14"
      // ? Instruksi 2: Buatlah variabel double? output;
      // ? Instruksi 3: Konversi input menjadi double dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is double && output == 3.14;
    },
    // Exercise 110
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "5.5"
      // ? Instruksi 2: Buatlah variabel double? output;
      // ? Instruksi 3: Konversi input menjadi double dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is double && output == 5.5;
    },
    // Exercise 111
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "true"
      // ? Instruksi 2: Buatlah variabel bool? output;
      // ? Instruksi 3: Konversi input menjadi boolean dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is bool && output == true;
    },
    // Exercise 112
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "false"
      // ? Instruksi 2: Buatlah variabel bool? output;
      // ? Instruksi 3: Konversi input menjadi boolean dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is bool && output == false;
    },
    // Exercise 113
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "0"
      // ? Instruksi 2: Buatlah variabel bool? output;
      // ? Instruksi 3: Konversi input menjadi boolean dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is bool && output == false;
    },
    // Exercise 114
    () {
      // ? Instruksi 1: Buatlah variabel bool input dengan nilai true
      // ? Instruksi 2: Buatlah variabel String? output;
      // ? Instruksi 3: Konversi input menjadi String dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is String && output == "true";
    },
    // Exercise 115
    () {
      // ? Instruksi 1: Buatlah variabel bool input dengan nilai false
      // ? Instruksi 2: Buatlah variabel String? output;
      // ? Instruksi 3: Konversi input menjadi String dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is String && output == "false";
    },
    // Exercise 116
    () {
      // ? Instruksi 1: Buatlah variabel int input dengan nilai 42
      // ? Instruksi 2: Buatlah variabel String? output;
      // ? Instruksi 3: Konversi input menjadi String dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is String && output == "42";
    },
    // Exercise 117
    () {
      // ? Instruksi 1: Buatlah variabel double input dengan nilai 3.14
      // ? Instruksi 2: Buatlah variabel String? output;
      // ? Instruksi 3: Konversi input menjadi String dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is String && output == "3.14";
    },
    // Exercise 118
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "9.99"
      // ? Instruksi 2: Buatlah variabel double? output;
      // ? Instruksi 3: Konversi input menjadi double dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is double && output == 9.99;
    },
    // Exercise 119
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "3.14"
      // ? Instruksi 2: Buatlah variabel double? output;
      // ? Instruksi 3: Konversi input menjadi double dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is double && output == 3.14;
    },
    // Exercise 120
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "5.5"
      // ? Instruksi 2: Buatlah variabel double? output;
      // ? Instruksi 3: Konversi input menjadi double dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is double && output == 5.5;
    },
    // Exercise 121
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "2023-08-09"
      // ? Instruksi 2: Buatlah variabel DateTime? output;
      // ? Instruksi 3: Konversi input menjadi DateTime dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is DateTime &&
          output.year == 2023 &&
          output.month == 8 &&
          output.day == 9;
    },
    // Exercise 122
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "1999-12-31"
      // ? Instruksi 2: Buatlah variabel DateTime? output;
      // ? Instruksi 3: Konversi input menjadi DateTime dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is DateTime &&
          output.year == 1999 &&
          output.month == 12 &&
          output.day == 31;
    },
    // Exercise 123
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "2022-01-15"
      // ? Instruksi 2: Buatlah variabel DateTime? output;
      // ? Instruksi 3: Konversi input menjadi DateTime dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is DateTime &&
          output.year == 2022 &&
          output.month == 1 &&
          output.day == 15;
    },
    // Exercise 124
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "1987-05-25"
      // ? Instruksi 2: Buatlah variabel DateTime? output;
      // ? Instruksi 3: Konversi input menjadi DateTime dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is DateTime &&
          output.year == 1987 &&
          output.month == 5 &&
          output.day == 25;
    },
    // Exercise 125
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "2025-10-01"
      // ? Instruksi 2: Buatlah variabel DateTime? output;
      // ? Instruksi 3: Konversi input menjadi DateTime dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is DateTime &&
          output.year == 2025 &&
          output.month == 10 &&
          output.day == 1;
    },
    // Exercise 126
    () {
      // ? Instruksi 1: Buatlah variabel List<int> input dengan nilai [1, 2, 3, 4, 5]
      // ? Instruksi 2: Buatlah variabel List<int>? output;
      // ? Instruksi 3: Konversi input menjadi List<int> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<int> &&
          output.length == 5 &&
          output[0] == 1 &&
          output[4] == 5;
    },
    // Exercise 127
    () {
      // ? Instruksi 1: Buatlah variabel List<String> input dengan nilai ["apple", "banana", "cherry"]
      // ? Instruksi 2: Buatlah variabel List<String>? output;
      // ? Instruksi 3: Konversi input menjadi List<String> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<String> &&
          output.length == 3 &&
          output[0] == "apple" &&
          output[2] == "cherry";
    },
    // Exercise 128
    () {
      // ? Instruksi 1: Buatlah variabel List<double> input dengan nilai [3.14, 2.71, 1.618]
      // ? Instruksi 2: Buatlah variabel List<double>? output;
      // ? Instruksi 3: Konversi input menjadi List<double> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<double> &&
          output.length == 3 &&
          output[0] == 3.14 &&
          output[2] == 1.618;
    },
    // Exercise 129
    () {
      // ? Instruksi 1: Buatlah variabel Map<String, int> input dengan nilai {"apple": 2, "banana": 3, "cherry": 5}
      // ? Instruksi 2: Buatlah variabel Map<String, int>? output;
      // ? Instruksi 3: Konversi input menjadi Map<String, int> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is Map<String, int> &&
          output.length == 3 &&
          output["apple"] == 2 &&
          output["cherry"] == 5;
    },
    // Exercise 130
    () {
      // ? Instruksi 1: Buatlah variabel Map<String, double> input dengan nilai {"pi": 3.14, "e": 2.71, "phi": 1.618}
      // ? Instruksi 2: Buatlah variabel Map<String, double>? output;
      // ? Instruksi 3: Konversi input menjadi Map<String, double> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is Map<String, double> &&
          output.length == 3 &&
          output["pi"] == 3.14 &&
          output["phi"] == 1.618;
    },
    // Exercise 131
    () {
      // ? Instruksi 1: Buatlah variabel Map<String, dynamic> input dengan nilai {"name": "John", "age": 30, "isStudent": true}
      // ? Instruksi 2: Buatlah variabel Map<String, dynamic>? output;
      // ? Instruksi 3: Konversi input menjadi Map<String, dynamic> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is Map<String, dynamic> &&
          output.length == 3 &&
          output["name"] == "John" &&
          output["isStudent"] == true;
    },
    // Exercise 132
    () {
      // ? Instruksi 1: Buatlah variabel Map<String, dynamic> input dengan nilai {"title": "Book", "price": 20.99, "isAvailable": false}
      // ? Instruksi 2: Buatlah variabel Map<String, dynamic>? output;
      // ? Instruksi 3: Konversi input menjadi Map<String, dynamic> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is Map<String, dynamic> &&
          output.length == 3 &&
          output["title"] == "Book" &&
          output["price"] == 20.99;
    },
    // Exercise 133
    () {
      // ? Instruksi 1: Buatlah variabel List<Map<String, int>> input dengan nilai [{"score": 90}, {"score": 85}, {"score": 95}]
      // ? Instruksi 2: Buatlah variabel List<Map<String, int>>? output;
      // ? Instruksi 3: Konversi input menjadi List<Map<String, int>> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, int>> &&
          output.length == 3 &&
          output[0]["score"] == 90 &&
          output[2]["score"] == 95;
    },
    // Exercise 134
    () {
      // ? Instruksi 1: Buatlah variabel List<Map<String, dynamic>> input dengan nilai [{"name": "Alice"}, {"name": "Bob"}, {"name": "Charlie"}]
      // ? Instruksi 2: Buatlah variabel List<Map<String, dynamic>>? output;
      // ? Instruksi 3: Konversi input menjadi List<Map<String, dynamic>> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output.length == 3 &&
          output[0]["name"] == "Alice" &&
          output[2]["name"] == "Charlie";
    },
    // Exercise 135
    () {
      // ? Instruksi 1: Buatlah variabel List<Map<String, dynamic>> input dengan nilai [{"city": "New York", "population": 8378394}, {"city": "Los Angeles", "population": 3990456}]
      // ? Instruksi 2: Buatlah variabel List<Map<String, dynamic>>? output;
      // ? Instruksi 3: Konversi input menjadi List<Map<String, dynamic>> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output.length == 2 &&
          output[0]["city"] == "New York" &&
          output[1]["population"] == 3990456;
    },
    // Exercise 136
    () {
      // ? Instruksi 1: Buatlah variabel List<Map<String, dynamic>> input dengan nilai [{"name": "Alice", "age": 25}, {"name": "Bob", "age": 30}]
      // ? Instruksi 2: Buatlah variabel List<Map<String, dynamic>>? output;
      // ? Instruksi 3: Konversi input menjadi List<Map<String, dynamic>> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output.length == 2 &&
          output[0]["name"] == "Alice" &&
          output[1]["age"] == 30;
    },
    // Exercise 137
    () {
      // ? Instruksi 1: Buatlah variabel List<Map<String, dynamic>> input dengan nilai [{"country": "USA", "capital": "Washington, D.C."}, {"country": "Canada", "capital": "Ottawa"}]
      // ? Instruksi 2: Buatlah variabel List<Map<String, dynamic>>? output;
      // ? Instruksi 3: Konversi input menjadi List<Map<String, dynamic>> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output.length == 2 &&
          output[0]["country"] == "USA" &&
          output[1]["capital"] == "Ottawa";
    },
    // Exercise 138
    () {
      // ? Instruksi 1: Buatlah variabel List<Map<String, dynamic>> input dengan nilai [{"code": "A1", "value": 10}, {"code": "B2", "value": 20}]
      // ? Instruksi 2: Buatlah variabel List<Map<String, dynamic>>? output;
      // ? Instruksi 3: Konversi input menjadi List<Map<String, dynamic>> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output.length == 2 &&
          output[0]["code"] == "A1" &&
          output[1]["value"] == 20;
    },
    // Exercise 139
    () {
      // ? Instruksi 1: Buatlah variabel List<Map<String, dynamic>> input dengan nilai [{"item": "Apple", "price": 1.99}, {"item": "Banana", "price": 0.99}]
      // ? Instruksi 2: Buatlah variabel List<Map<String, dynamic>>? output;
      // ? Instruksi 3: Konversi input menjadi List<Map<String, dynamic>> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output.length == 2 &&
          output[0]["item"] == "Apple" &&
          output[1]["price"] == 0.99;
    },
    // Exercise 140
    () {
      // ? Instruksi 1: Buatlah variabel List<Map<String, dynamic>> input dengan nilai [{"name": "Alice", "age": 25}, {"name": "Bob", "age": 30}]
      // ? Instruksi 2: Buatlah variabel List<Map<String, dynamic>>? output;
      // ? Instruksi 3: Konversi input menjadi List<Map<String, dynamic>> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output.length == 2 &&
          output[0]["name"] == "Alice" &&
          output[1]["age"] == 30;
    },
    // Exercise 141
    () {
      // ? Instruksi 1: Buatlah variabel List<Map<String, dynamic>> input dengan nilai [{"city": "New York", "population": 8378394}, {"city": "Los Angeles", "population": 3990456}]
      // ? Instruksi 2: Buatlah variabel List<Map<String, dynamic>>? output;
      // ? Instruksi 3: Konversi input menjadi List<Map<String, dynamic>> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output.length == 2 &&
          output[0]["city"] == "New York" &&
          output[1]["population"] == 3990456;
    },
    // Exercise 142
    () {
      // ? Instruksi 1: Buatlah variabel List<Map<String, dynamic>> input dengan nilai [{"country": "USA", "capital": "Washington, D.C."}, {"country": "Canada", "capital": "Ottawa"}]
      // ? Instruksi 2: Buatlah variabel List<Map<String, dynamic>>? output;
      // ? Instruksi 3: Konversi input menjadi List<Map<String, dynamic>> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output.length == 2 &&
          output[0]["country"] == "USA" &&
          output[1]["capital"] == "Ottawa";
    },
    // Exercise 143
    () {
      // ? Instruksi 1: Buatlah variabel List<Map<String, dynamic>> input dengan nilai [{"code": "A1", "value": 10}, {"code": "B2", "value": 20}]
      // ? Instruksi 2: Buatlah variabel List<Map<String, dynamic>>? output;
      // ? Instruksi 3: Konversi input menjadi List<Map<String, dynamic>> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output.length == 2 &&
          output[0]["code"] == "A1" &&
          output[1]["value"] == 20;
    },
    // Exercise 144
    () {
      // ? Instruksi 1: Buatlah variabel List<Map<String, dynamic>> input dengan nilai [{"item": "Apple", "price": 1.99}, {"item": "Banana", "price": 0.99}]
      // ? Instruksi 2: Buatlah variabel List<Map<String, dynamic>>? output;
      // ? Instruksi 3: Konversi input menjadi List<Map<String, dynamic>> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<Map<String, dynamic>> &&
          output.length == 2 &&
          output[0]["item"] == "Apple" &&
          output[1]["price"] == 0.99;
    },
    // Exercise 145
    () {
      // ? Instruksi 1: Buatlah variabel Map<String, dynamic> input dengan nilai {"name": "Alice", "age": 25}
      // ? Instruksi 2: Buatlah variabel bool? output;
      // ? Instruksi 3: Gunakan operator conditional Jika input["age"] == 25, atur nilai output menjadi true
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output == true;
    },
    // Exercise 146
    () {
      // ? Instruksi 1: Buatlah variabel Map<String, dynamic> input dengan nilai {"amount": 20.5, "isDiscounted": 1}
      // ? Instruksi 2: Buatlah variabel bool? output;
      // ? Instruksi 3: Gunakan operator conditional Jika input["isDiscounted"] == 1, atur nilai output menjadi true
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output == true;
    },
    // Exercise 147
    () {
      // ? Instruksi 1: Buatlah variabel Map<String, dynamic> input dengan nilai {"isActive": "true"}
      // ? Instruksi 2: Buatlah variabel bool? output;
      // ? Instruksi 3: Gunakan operator conditional Jika input["isActive"] == "true", atur nilai output menjadi true
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output == true;
    },
    // Exercise 148
    () {
      // ? Instruksi 1: Buatlah variabel Map<String, dynamic> input dengan nilai {"hasPermission": "false"}
      // ? Instruksi 2: Buatlah variabel bool? output;
      // ? Instruksi 3: Gunakan operator conditional Jika input["hasPermission"] == "false", atur nilai output menjadi true
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output == true;
    },
    // Exercise 149
    () {
      // ? Instruksi 1: Buatlah variabel Map<String, dynamic> input dengan nilai {"isAvailable": "1"}
      // ? Instruksi 2: Buatlah variabel bool? output;
      // ? Instruksi 3: Gunakan operator conditional Jika input["isAvailable"] == "1", atur nilai output menjadi true
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output == true;
    },
    // Exercise 150
    () {
      // ? Instruksi 1: Buatlah variabel Map<String, dynamic> input dengan nilai {"isEnabled": "0"}
      // ? Instruksi 2: Buatlah variabel bool? output;
      // ? Instruksi 3: Gunakan operator conditional Jika input["isEnabled"] == "0", atur nilai output menjadi true
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output == true;
    },
    // Exercise 151
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "apple,banana,orange"
      // ? Instruksi 2: Buatlah variabel List<String>? output;
      // ? Instruksi 3: Konversi nilai dari input menjadi List<String> dengan memisahkan string berdasarkan koma (",") dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<String> &&
          output.length == 3 &&
          output.contains("apple") &&
          output.contains("banana") &&
          output.contains("orange");
    },
    // Exercise 152
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "42,38,56,29"
      // ? Instruksi 2: Buatlah variabel List<int>? output;
      // ? Instruksi 3: Konversi nilai dari input menjadi List<int> dengan memisahkan string berdasarkan koma (",") dan mengkonversi setiap nilai menjadi integer, kemudian tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<int> &&
          output.length == 4 &&
          output.contains(42) &&
          output.contains(38) &&
          output.contains(56) &&
          output.contains(29);
    },
    // Exercise 153
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "true,false,true,false"
      // ? Instruksi 2: Buatlah variabel List<bool>? output;
      // ? Instruksi 3: Konversi nilai dari input menjadi List<bool> dengan memisahkan string berdasarkan koma (",") dan mengkonversi setiap nilai menjadi boolean, kemudian tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<bool> &&
          output.length == 4 &&
          output.contains(true) &&
          output.contains(false);
    },
    // Exercise 154
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "3.14,2.718,1.618"
      // ? Instruksi 2: Buatlah variabel List<double>? output;
      // ? Instruksi 3: Konversi nilai dari input menjadi List<double> dengan memisahkan string berdasarkan koma (",") dan mengkonversi setiap nilai menjadi double, kemudian tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<double> &&
          output.length == 3 &&
          output.contains(3.14) &&
          output.contains(2.718) &&
          output.contains(1.618);
    },
    // Exercise 155
    () {
      // ? Instruksi 1: Buatlah variabel String input dengan nilai "2022-01-01,2023-05-15,2024-10-30"
      // ? Instruksi 2: Buatlah variabel List<DateTime>? output;
      // ? Instruksi 3: Konversi nilai dari input menjadi List<DateTime> dengan memisahkan string berdasarkan koma (",") dan mengkonversi setiap nilai menjadi DateTime, kemudian tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---
      return output is List<DateTime> && output.length == 3;
    },
    // Exercise 156
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "1,2,3,4,5"
      // ? Instruksi: Buatlah variabel List<int>? output;
      // ? Instruksi: Konversi input menjadi List<int> dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<int>;
    },
    // Exercise 157
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "3.14"
      // ? Instruksi: Buatlah variabel double? output;
      // ? Instruksi: Konversi input menjadi double dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is double && output == 3.14;
    },
    // Exercise 158
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "true"
      // ? Instruksi: Buatlah variabel bool? output;
      // ? Instruksi: Konversi input menjadi bool dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is bool && output;
    },
    // Exercise 159
    () {
      // ? Instruksi: Buatlah variabel int input dengan nilai 42
      // ? Instruksi: Buatlah variabel bool? output;
      // ? Instruksi: Konversi input menjadi String dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "42";
    },
    // Exercise 160
    () {
      // ? Instruksi: Buatlah variabel double input dengan nilai 3.14
      // ? Instruksi: Buatlah variabel String? output;
      // ? Instruksi: Konversi input menjadi String dan tampung di dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "3.14";
    },
    // Exercise 161
    () {
      // ? Instruksi: Buatlah variabel List<int> input dengan nilai [1, 2, 3, 4, 5]
      // ? Instruksi: Buatlah variabel bool? output;
      // ? Instruksi: Konversi input menjadi String dan cek apakah string "3" terdapat dalam output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is bool && output;
    },
    // Exercise 162
    () {
      // ? Instruksi: Buatlah variabel List<String> input dengan nilai ["apple", "banana", "cherry"]
      // ? Instruksi: Buatlah variabel bool? output;
      // ? Instruksi: Konversi input menjadi String dan cek apakah string "grape" terdapat dalam output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is bool && !output;
    },
    // Exercise 163
    () {
      // ? Instruksi: Buatlah variabel List<int> input dengan nilai [10, 20, 30, 40, 50]
      // ? Instruksi: Buatlah variabel bool? output;
      // ? Instruksi: Konversi input menjadi List<String> dengan mengubah setiap elemen menjadi string
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.every((element) => element is String);
    },
    // Exercise 164
    () {
      // ? Instruksi: Buatlah variabel Map<String, int> input dengan pasangan nilai "apple" -> 3 dan "banana" -> 2
      // ? Instruksi: Buatlah variabel bool? output;
      // ? Instruksi: Konversi input menjadi List<String> dengan mengambil semua kunci (keys) dari map
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.every((element) => element is String);
    },
    // Exercise 165
    () {
      // ? Instruksi: Buatlah variabel Map<int, String> input dengan pasangan nilai 1 -> "one" dan 2 -> "two"
      // ? Instruksi: Buatlah variabel bool? output;
      // ? Instruksi: Konversi input menjadi List<int> dengan mengambil semua nilai (values) dari map
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.every((element) => element is String);
    },
    // Exercise 166
    () {
      // ? Instruksi: Buatlah variabel List<Map<String, int>> input dengan nilai [{ "apple": 3 }, { "banana": 2 }]
      // ? Instruksi: Buatlah variabel bool? output;
      // ? Instruksi: Konversi input menjadi List<int> dengan mengambil semua nilai dari map-map di dalam list
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<int> && output.every((element) => element is int);
    },
    // Exercise 167
    () {
      // ? Instruksi: Buatlah variabel Map<String, dynamic> input dengan pasangan nilai "age" -> 25 dan "name" -> "John"
      // ? Instruksi: Buatlah variabel bool? output;
      // ? Instruksi: Konversi input menjadi List<dynamic> dengan mengambil semua nilai dari map
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<dynamic>;
    },
    // Exercise 168
    () {
      // ? Instruksi: Buatlah variabel List<int> input dengan nilai [1, 2, 3, 4, 5]
      // ? Instruksi: Buatlah variabel bool? output;
      // ? Instruksi: Konversi input menjadi Map<String, int> dengan mengubah setiap elemen menjadi pasangan kunci "number" dan nilai elemen
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is Map<String, int> && output.containsKey("number");
    },
    // Exercise 169
    () {
      // ? Instruksi: Buatlah variabel List<String> input dengan nilai ["apple", "banana", "cherry"]
      // ? Instruksi: Buatlah variabel bool? output;
      // ? Instruksi: Konversi input menjadi Map<String, String> dengan mengubah setiap elemen menjadi pasangan kunci dan nilai yang sama
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is Map<String, String>;
    },
    // Exercise 170
    () {
      // ? Instruksi: Buatlah variabel List<Map<String, int>> input dengan nilai [{ "apple": 3 }, { "banana": 2 }]
      // ? Instruksi: Buatlah variabel bool? output;
      // ? Instruksi: Konversi input menjadi Map<String, int> dengan mengambil pasangan kunci "apple" dan nilai dari map pertama dalam list
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is Map<String, int> && output.containsKey("apple");
    },
    // Exercise 171
    () {
      // ? Instruksi: Buatlah variabel String input1 dengan nilai "Hello"
      // ? Instruksi: Buatlah variabel String input2 dengan nilai "world"
      // ? Instruksi: Buatlah variabel String? output;
      // ? Instruksi: Gabungkan input1 dan input2 menjadi satu string dan simpan dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "Hello world";
    },
    // Exercise 172
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "Hello, my name is John"
      // ? Instruksi: Buatlah variabel String? output;
      // ? Instruksi: Ganti kata "John" menjadi "Alice" dalam input dan simpan dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "Hello, my name is Alice";
    },
    // Exercise 173
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple,banana,cherry"
      // ? Instruksi: Buatlah variabel List<String>? output;
      // ? Instruksi: Konversi input menjadi List<String> dengan memisahkan string berdasarkan koma (",")
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.length == 3 &&
          output.every((element) => element is String);
    },
    // Exercise 174
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "10,20,30,40,50"
      // ? Instruksi: Buatlah variabel List<int>? output;
      // ? Instruksi: Konversi input menjadi List<int> dengan mengubah setiap elemen menjadi integer
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<int> &&
          output.length == 5 &&
          output.every((element) => element is int);
    },
    // Exercise 175
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "1.5,2.5,3.5"
      // ? Instruksi: Buatlah variabel List<double>? output;
      // ? Instruksi: Konversi input menjadi List<double> dengan mengubah setiap elemen menjadi double
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<double> &&
          output.length == 3 &&
          output.every((element) => element is double);
    },
    // Exercise 176
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "true,false,true"
      // ? Instruksi: Buatlah variabel List<bool>? output;
      // ? Instruksi: Konversi input menjadi List<bool> dengan mengubah setiap elemen menjadi boolean
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<bool> &&
          output.length == 3 &&
          output.every((element) => element is bool);
    },
    // Exercise 177
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "2022-08-01,2023-01-15,2021-05-10"
      // ? Instruksi: Buatlah variabel List<DateTime>? output;
      // ? Instruksi: Konversi input menjadi List<DateTime> dengan mengubah setiap elemen menjadi DateTime
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<DateTime> &&
          output.length == 3 &&
          output.every((element) => element is DateTime);
    },
    // Exercise 178
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple,banana,cherry"
      // ? Instruksi: Buatlah variabel Map<String, int>? output;
      // ? Instruksi: Konversi input menjadi Map<String, int> dengan mengubah setiap elemen menjadi pasangan kunci "fruit" dan nilai 1
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is Map<String, int> && output.length == 3;
    },
    // Exercise 179
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "10,20,30"
      // ? Instruksi: Buatlah variabel Map<int, String>? output;
      // ? Instruksi: Konversi input menjadi Map<int, String> dengan mengubah setiap elemen menjadi pasangan kunci integer dan nilai "value"
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is Map<int, String> && output.length == 3;
    },
    // Exercise 180
    () {
      // ? Instruksi: Buatlah variabel List<Map<String, int>> input dengan nilai [{ "apple": 3 }, { "banana": 2 }, { "cherry": 1 }]
      // ? Instruksi: Buatlah variabel List<int>? output;
      // ? Instruksi: Konversi input menjadi List<int> dengan mengambil nilai dari setiap map dalam list
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<int> &&
          output.length == 3 &&
          output.contains(3) &&
          output.contains(2) &&
          output.contains(1);
    },
    // Exercise 181
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "Hello, world!"
      // ? Instruksi: Buatlah variabel String? output;
      // ? Instruksi: Ganti kata "world" menjadi "Dart" dalam input dan simpan dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "Hello, Dart!";
    },
    // Exercise 182
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple,banana,apple,apple,cherry"
      // ? Instruksi: Buatlah variabel String? output;
      // ? Instruksi: Ganti semua kata "apple" menjadi "orange" dalam input dan simpan dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is String && output == "orange,banana,orange,orange,cherry";
    },
    // Exercise 183
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "1,2,3,4,5"
      // ? Instruksi: Buatlah variabel List<int>? output;
      // ? Instruksi: Konversi input menjadi List<int> dengan mengubah setiap elemen menjadi integer
      // ? Instruksi: Ganti semua angka yang habis dibagi 2 dengan nilai 0 dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<int> &&
          output.length == 5 &&
          output.contains(0) &&
          !output.contains(2) &&
          !output.contains(4);
    },
    // Exercise 184
    () {
      // ? Instruksi: Buatlah variabel List<String> input dengan nilai ["apple", "banana", "cherry"]
      // ? Instruksi: Buatlah variabel Map<String, int>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi pasangan kunci "fruit" dan panjang string dalam map output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is Map<String, int> &&
          output.length == 3 &&
          output["apple"] == 5 &&
          output["banana"] == 6 &&
          output["cherry"] == 6;
    },
    // Exercise 185
    () {
      // ? Instruksi: Buatlah variabel List<int> input dengan nilai [1, 2, 3, 4, 5]
      // ? Instruksi: Buatlah variabel Map<int, int>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi pasangan kunci integer dan kuadrat dari elemen dalam map output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is Map<int, int> &&
          output.length == 5 &&
          output[1] == 1 &&
          output[2] == 4 &&
          output[3] == 9 &&
          output[4] == 16 &&
          output[5] == 25;
    },
    // Exercise 186
    () {
      // ? Instruksi: Buatlah variabel List<String> input dengan nilai ["apple", "banana", "cherry"]
      // ? Instruksi: Buatlah variabel List<Map<String, int>>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi map dengan pasangan kunci "length" dan panjang string sebagai nilai, lalu tambahkan dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<Map<String, int>> &&
          output.length == 3 &&
          output[0]["length"] == 5 &&
          output[1]["length"] == 6 &&
          output[2]["length"] == 6;
    },
    // Exercise 187
    () {
      // ? Instruksi: Buatlah variabel List<Map<String, dynamic>> input dengan nilai [{"fruit": "apple"}, {"fruit": "banana"}, {"fruit": "cherry"}]
      // ? Instruksi: Buatlah variabel List<String>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi string "fruit" dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.length == 3 &&
          output.contains("apple") &&
          output.contains("banana") &&
          output.contains("cherry");
    },
    // Exercise 188
    () {
      // ? Instruksi: Buatlah variabel List<Map<String, int>> input dengan nilai [{"amount": 5}, {"amount": 10}, {"amount": 3}]
      // ? Instruksi: Buatlah variabel List<int>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi integer "amount" dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<int> &&
          output.length == 3 &&
          output.contains(5) &&
          output.contains(10) &&
          output.contains(3);
    },
    // Exercise 189
    () {
      // ? Instruksi: Buatlah variabel List<Map<String, dynamic>> input dengan nilai [{"value": 7}, {"value": 15}, {"value": 9}]
      // ? Instruksi: Buatlah variabel List<int>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi integer "value" dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<int> &&
          output.length == 3 &&
          output.contains(7) &&
          output.contains(15) &&
          output.contains(9);
    },
    // Exercise 190
    () {
      // ? Instruksi: Buatlah variabel List<String> input dengan nilai ["5", "10", "3"]
      // ? Instruksi: Buatlah variabel List<int>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi integer dan tambahkan dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<int> &&
          output.length == 3 &&
          output.contains(5) &&
          output.contains(10) &&
          output.contains(3);
    },
    // Exercise 191
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "5,10,15,20,25"
      // ? Instruksi: Buatlah variabel List<int>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi integer dan tambahkan dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<int> &&
          output.length == 5 &&
          output.contains(5) &&
          output.contains(10) &&
          output.contains(15) &&
          output.contains(20) &&
          output.contains(25);
    },
    // Exercise 192
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "5.5,10.5,15.5,20.5,25.5"
      // ? Instruksi: Buatlah variabel List<double>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi double dan tambahkan dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<double> &&
          output.length == 5 &&
          output.contains(5.5) &&
          output.contains(10.5) &&
          output.contains(15.5) &&
          output.contains(20.5) &&
          output.contains(25.5);
    },
    // Exercise 193
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "true,false,true,false,true"
      // ? Instruksi: Buatlah variabel List<bool>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi boolean dan tambahkan dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<bool> &&
          output.length == 5 &&
          output.contains(true) &&
          output.contains(false);
    },
    // Exercise 194
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple,banana,apple,banana,apple"
      // ? Instruksi: Buatlah variabel List<String>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi string dan tambahkan dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.length == 5 &&
          output.contains("apple") &&
          output.contains("banana");
    },
    // Exercise 195
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "2022-01-01,2023-02-02,2024-03-03"
      // ? Instruksi: Buatlah variabel List<DateTime>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi DateTime dan tambahkan dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<DateTime> &&
          output.length == 3 &&
          output.contains(DateTime(2022, 1, 1)) &&
          output.contains(DateTime(2023, 2, 2)) &&
          output.contains(DateTime(2024, 3, 3));
    },
    // Exercise 196
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "1,2,3,4,5"
      // ? Instruksi: Buatlah variabel List<int>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi integer dan tambahkan dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<int> &&
          output.length == 5 &&
          output.contains(1) &&
          output.contains(2) &&
          output.contains(3) &&
          output.contains(4) &&
          output.contains(5);
    },
    // Exercise 197
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "1.1,2.2,3.3,4.4,5.5"
      // ? Instruksi: Buatlah variabel List<double>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi double dan tambahkan dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<double> &&
          output.length == 5 &&
          output.contains(1.1) &&
          output.contains(2.2) &&
          output.contains(3.3) &&
          output.contains(4.4) &&
          output.contains(5.5);
    },
    // Exercise 198
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "true,false,true,false,true"
      // ? Instruksi: Buatlah variabel List<bool>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi boolean dan tambahkan dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<bool> &&
          output.length == 5 &&
          output.contains(true) &&
          output.contains(false);
    },
    // Exercise 199
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple,banana,apple,banana,apple"
      // ? Instruksi: Buatlah variabel List<String>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi string dan tambahkan dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.length == 5 &&
          output.contains("apple") &&
          output.contains("banana");
    },
    // Exercise 200
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "2022-01-01,2023-02-02,2024-03-03"
      // ? Instruksi: Buatlah variabel List<DateTime>? output;
      // ? Instruksi: Konversi setiap elemen dalam input menjadi DateTime dan tambahkan dalam list output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<DateTime> &&
          output.length == 3 &&
          output.contains(DateTime(2022, 1, 1)) &&
          output.contains(DateTime(2023, 2, 2)) &&
          output.contains(DateTime(2024, 3, 3));
    },
    // Exercise 201
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple,banana,cherry,dates,elderberry"
      // ? Instruksi: Buatlah variabel List<String>? output;
      // ? Instruksi: Konversi input menjadi list string dan tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.length == 5 &&
          output.contains("apple") &&
          output.contains("banana") &&
          output.contains("cherry") &&
          output.contains("dates") &&
          output.contains("elderberry");
    },
    // Exercise 202
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "1.1,2.2,3.3,4.4,5.5"
      // ? Instruksi: Buatlah variabel List<double>? output;
      // ? Instruksi: Konversi input menjadi list double dan tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<double> &&
          output.length == 5 &&
          output.contains(1.1) &&
          output.contains(2.2) &&
          output.contains(3.3) &&
          output.contains(4.4) &&
          output.contains(5.5);
    },
    // Exercise 203
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "true,false,true,false,true"
      // ? Instruksi: Buatlah variabel List<bool>? output;
      // ? Instruksi: Konversi input menjadi list boolean dan tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<bool> &&
          output.length == 5 &&
          output.contains(true) &&
          output.contains(false);
    },
    // Exercise 204
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "2022-01-01,2023-02-02,2024-03-03"
      // ? Instruksi: Buatlah variabel List<DateTime>? output;
      // ? Instruksi: Konversi input menjadi list DateTime dan tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<DateTime> &&
          output.length == 3 &&
          output.contains(DateTime(2022, 1, 1)) &&
          output.contains(DateTime(2023, 2, 2)) &&
          output.contains(DateTime(2024, 3, 3));
    },
    // Exercise 205
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple,banana,cherry,dates,elderberry"
      // ? Instruksi: Buatlah variabel List<String>? output;
      // ? Instruksi: Konversi input menjadi list string dan tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.length == 5 &&
          output.contains("apple") &&
          output.contains("banana") &&
          output.contains("cherry") &&
          output.contains("dates") &&
          output.contains("elderberry");
    },
    // Exercise 206
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple,banana,cherry,dates,elderberry"
      // ? Instruksi: Buatlah variabel List<String>? output;
      // ? Instruksi: Konversi input menjadi list string dan tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.length == 5 &&
          output.contains("apple") &&
          output.contains("banana") &&
          output.contains("cherry") &&
          output.contains("dates") &&
          output.contains("elderberry");
    },
    // Exercise 207
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "1.1,2.2,3.3,4.4,5.5"
      // ? Instruksi: Buatlah variabel List<double>? output;
      // ? Instruksi: Konversi input menjadi list double dan tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<double> &&
          output.length == 5 &&
          output.contains(1.1) &&
          output.contains(2.2) &&
          output.contains(3.3) &&
          output.contains(4.4) &&
          output.contains(5.5);
    },
    // Exercise 208
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "true,false,true,false,true"
      // ? Instruksi: Buatlah variabel List<bool>? output;
      // ? Instruksi: Konversi input menjadi list boolean dan tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<bool> &&
          output.length == 5 &&
          output.contains(true) &&
          output.contains(false);
    },
    // Exercise 209
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "2022-01-01,2023-02-02,2024-03-03"
      // ? Instruksi: Buatlah variabel List<DateTime>? output;
      // ? Instruksi: Konversi input menjadi list DateTime dan tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<DateTime> &&
          output.length == 3 &&
          output.contains(DateTime(2022, 1, 1)) &&
          output.contains(DateTime(2023, 2, 2)) &&
          output.contains(DateTime(2024, 3, 3));
    },
    // Exercise 210
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple,banana,cherry,dates,elderberry"
      // ? Instruksi: Buatlah variabel List<String>? output;
      // ? Instruksi: Konversi input menjadi list string dan tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.length == 5 &&
          output.contains("apple") &&
          output.contains("banana") &&
          output.contains("cherry") &&
          output.contains("dates") &&
          output.contains("elderberry");
    },
    // Exercise 211
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple,banana,cherry,dates,elderberry"
      // ? Instruksi: Buatlah variabel List<String>? output;
      // ? Instruksi: Konversi input menjadi list string dan tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.length == 5 &&
          output.contains("apple") &&
          output.contains("banana") &&
          output.contains("cherry") &&
          output.contains("dates") &&
          output.contains("elderberry");
    },
    // Exercise 212
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "1.1,2.2,3.3,4.4,5.5"
      // ? Instruksi: Buatlah variabel List<double>? output;
      // ? Instruksi: Konversi input menjadi list double dan tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<double> &&
          output.length == 5 &&
          output.contains(1.1) &&
          output.contains(2.2) &&
          output.contains(3.3) &&
          output.contains(4.4) &&
          output.contains(5.5);
    },
    // Exercise 213
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "true,false,true,false,true"
      // ? Instruksi: Buatlah variabel List<bool>? output;
      // ? Instruksi: Konversi input menjadi list boolean dan tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<bool> &&
          output.length == 5 &&
          output.contains(true) &&
          output.contains(false);
    },
    // Exercise 214
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "2022-01-01,2023-02-02,2024-03-03"
      // ? Instruksi: Buatlah variabel List<DateTime>? output;
      // ? Instruksi: Konversi input menjadi list DateTime dan tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<DateTime> &&
          output.length == 3 &&
          output.contains(DateTime(2022, 1, 1)) &&
          output.contains(DateTime(2023, 2, 2)) &&
          output.contains(DateTime(2024, 3, 3));
    },
    // Exercise 215
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple,banana,cherry,dates,elderberry"
      // ? Instruksi: Buatlah variabel List<String>? output;
      // ? Instruksi: Konversi input menjadi list string dan tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is List<String> &&
          output.length == 5 &&
          output.contains("apple") &&
          output.contains("banana") &&
          output.contains("cherry") &&
          output.contains("dates") &&
          output.contains("elderberry");
    },
    // Exercise 216
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple,banana,cherry,dates,elderberry"
      // ? Instruksi: Buatlah variabel Map<String, int>? output;
      // ? Instruksi: Konversi input menjadi map dengan keys berdasarkan kata dan values berdasarkan panjang kata, tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is Map<String, int> &&
          output.length == 5 &&
          output["apple"] == 5 &&
          output["banana"] == 6 &&
          output["cherry"] == 6 &&
          output["dates"] == 5 &&
          output["elderberry"] == 10;
    },
    // Exercise 217
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple:100,banana:200,cherry:300"
      // ? Instruksi: Buatlah variabel Map<String, int>? output;
      // ? Instruksi: Konversi input menjadi map dengan keys berdasarkan nama buah dan values berdasarkan jumlahnya, tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is Map<String, int> &&
          output.length == 3 &&
          output["apple"] == 100 &&
          output["banana"] == 200 &&
          output["cherry"] == 300;
    },
    // Exercise 218
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple:1.1,banana:2.2,cherry:3.3"
      // ? Instruksi: Buatlah variabel Map<String, double>? output;
      // ? Instruksi: Konversi input menjadi map dengan keys berdasarkan nama buah dan values berdasarkan angka, tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is Map<String, double> &&
          output.length == 3 &&
          output["apple"] == 1.1 &&
          output["banana"] == 2.2 &&
          output["cherry"] == 3.3;
    },
    // Exercise 219
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple:true,banana:false,cherry:true"
      // ? Instruksi: Buatlah variabel Map<String, bool>? output;
      // ? Instruksi: Konversi input menjadi map dengan keys berdasarkan nama buah dan values berdasarkan nilai boolean, tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is Map<String, bool> &&
          output.length == 3 &&
          output["apple"] == true &&
          output["banana"] == false &&
          output["cherry"] == true;
    },
    // Exercise 220
    () {
      // ? Instruksi: Buatlah variabel String input dengan nilai "apple:2022-01-01,banana:2023-02-02,cherry:2024-03-03"
      // ? Instruksi: Buatlah variabel Map<String, DateTime>? output;
      // ? Instruksi: Konversi input menjadi map dengan keys berdasarkan nama buah dan values berdasarkan tanggal, tampung dalam variabel output
      // >>> Tulis jawabanmu di bawah ini

      // --- End of Answer ---

      return output is Map<String, DateTime> &&
          output.length == 3 &&
          output["apple"] == DateTime(2022, 1, 1) &&
          output["banana"] == DateTime(2023, 2, 2) &&
          output["cherry"] == DateTime(2024, 3, 3);
    },
    // Exercise 221
    () {
      //Ubah tipe data variable dibawah ini menjadi String
      int price = 100;
      return price is String;
    },

    // Exercise 222
    () {
      double? price;
      String text = "100.24";
      //Ubahlah variable text di atas menjadi double,
      //dan isilah varibel price dengan hasil konversinya
      //di bagian bawah
      return price == 100.24;
    },

    // Exercise 223
    () {
      double? price;
      //Uncomment kode dibawah ini
      //Perbaiki kode-nya agar tidak error
      //[TIPS] Hilangkan semua String selain angka 0-9 dan titik.
      //Gunakan Regex seperti ini: .replaceAll(RegExp(r'[^\d.]'), '')

      String text = "300.24a";
      // price = double.tryParse(text) ?? 0;
      return price == 300.24;
    },

    // Exercise 224
    () {
      int input = 12;
      // Tuliskan kode untuk memverifikasi apakah input adalah bilangan ganjil
      bool? output;
      return output == false;
    },

    // Exercise 225
    () {
      double? total;

      //Uncomment kode dibawah ini!
      //Kode dibawah akan error jika di jalankan,
      //Perbaiki dengan meng-gunakan .tryParse("300aa")??0
      //Sehingga ketika parameter-nya tidak valid, nilainya menjadi 0
      /*
          total = double.parse("300aa");
          */
      return total != null;
    },

    // Exercise 226
    () {
      int? age;

      //Uncomment kode dibawah ini!
      //Kode dibawah akan error jika di jalankan,
      //Perbaiki dengan meng-gunakan .tryParse("39ads")??0
      //Sehingga ketika parameter-nya tidak valid, nilainya menjadi 0

      /*
    age = int.parse("39ads");
    */

      return age != null;
    },

    // Exercise 227
    () {
      int price = 0;
      String value = "5000";

      // Uncomment kode dibawah, dan perbaiki agar tidak error
      /*
    value = price;
    */
      return price == 5000;
    },

    // Exercise 228
    () {
      //Ini adalah contoh kode untuk mengambil Text diantara ' dan '.
      /*
    String str = "The text is between 'this'";
    int startIndex = str.indexOf("'") + 1;
    int endIndex = str.lastIndexOf("'");
    String textBetweenQuotes = str.substring(startIndex, endIndex);
    */

      String text = "hello 'Deny', apa kabar?";
      String? name;
      //Berdasarkan referensi di atas,
      //Ambil text diantara ' dan ' pada variable text
      return name == "Deny";
    },

    // Exercise 229
    () {
      List numbers = [70, 23, 44, 33, 100, 23, 109];
      double average = 0;
      double total = 0;
      /*
          Hitunglah nilai rata2 dari List di atas.
          [TIPS] Gunakan for untuk mendapatkan total.
          Gunakan numbers.length untuk mendapatkan panjang List
          */
      return average.toStringAsFixed(2) == "57.43";
    },

    // Exercise 230
    () {
      List numbers = [70, 23, 44, 33, 100, 23, 109];
      /*
          Hitunglah minValue dan maxValue dari List numbers di atas.
          [Tips] - Gunakan .sort, ambil minValue dari .first dan ambil maxValue
          dari .last
          */
      int minValue = 0;
      int maxValue = 0;

      return minValue == 23 && maxValue == 109;
    },

    // Exercise 231
    () {
      int input = 10;
      // Tuliskan kode untuk menambahkan 5 pada input
      int? output;

      return output == 15;
    },

    // Exercise 232
    () {
      int input = 10;
      // Tuliskan kode untuk mengurangi 5 pada input
      int? output;

      return output == 5;
    },

    // Exercise 233
    () {
      int input1 = 10;
      int input2 = 20;
      // Tuliskan kode untuk menjumlahkan input1 dan input2
      int? output;

      return output == 30;
    },

    // Exercise 234
    () {
      int input1 = 10;
      int input2 = 20;
      // Tuliskan kode untuk mengurangi input2 dengan input1
      int? output;

      return output == 10;
    },

    // Exercise 235
    () {
      int input1 = 10;
      int input2 = 20;
      // Tuliskan kode untuk membagi input2 dengan input1
      double? output;

      return output == 2.0;
    },

    // Exercise 236
    () {
      int input1 = 10;
      int input2 = 20;
      // Tuliskan kode untuk mengalikan input1 dan input2
      int? output;

      return output == 200;
    },

    // Exercise 237
    () {
      int input1 = 10;
      int input2 = 20;
      // Tuliskan kode untuk menghitung sisa bagi input2 dengan input1
      int? output;

      return output == 0;
    },

    // Exercise 238
    () {
      String input = "Hello";
      // Tuliskan kode untuk menambahkan " World!" pada input
      String? output = "";

      return output == "Hello World!";
    },

    // Exercise 239
    () {
      String input = "Hello World!";
      // Tuliskan kode untuk mengambil kata pertama dari input
      String? output = "";

      return output == "Hello";
    },

    // Exercise 240
    () {
      String input = "Hello World!";
      // Tuliskan kode untuk mengambil kata kedua dari input
      String? output = "";

      return output == "World!";
    },

    // Exercise 241
    () {
      int input = 12345;
      // Tuliskan kode untuk memverifikasi apakah input adalah bilangan genap
      bool? output;

      return output == false;
    },

    // Exercise 242
    () {
      int input = 12345;
      // Tuliskan kode untuk memverifikasi apakah input adalah bilangan ganjil
      bool? output;

      return output == true;
    },

    // Exercise 243
    () {
      String input = "Dart";
      // Tuliskan kode untuk memverifikasi apakah input memiliki panjang lebih dari 3 karakter
      bool? output;

      return output == true;
    },

    // Exercise 244
    () {
      String input = "Dart";
      // Tuliskan kode untuk memverifikasi apakah input memiliki panjang sama dengan 3 karakter
      bool? output;

      return output == false;
    },

    // Exercise 245
    () {
      String input = "Dart";
      // Tuliskan kode untuk memverifikasi apakah input memiliki huruf pertama 'D'
      bool? output;

      return output == true;
    },

    // Exercise 246
    () {
      String input = "Dart";
      // Tuliskan kode untuk memverifikasi apakah input memiliki huruf terakhir 't'
      bool? output;

      return output == true;
    },

    // Exercise 247
    () {
      int input = 12345;
      // Tuliskan kode untuk memverifikasi apakah input memiliki 5 digit
      bool? output;

      return output == true;
    },

    // Exercise 248
    () {
      int input = 12345;
      // Tuliskan kode untuk memverifikasi apakah input memiliki 4 digit
      bool? output;

      return output == false;
    },

    // Exercise 249
    () {
      double input = 123.45;
      // Tuliskan kode untuk memverifikasi apakah input memiliki 2 digit setelah koma
      bool? output;

      return output == true;
    },

    // Exercise 250
    () {
      double input = 123.45;
      // Tuliskan kode untuk memverifikasi apakah input memiliki 3 digit setelah koma
      bool? output;

      return output == false;
    },

    // Exercise 251
    () {
      String input = "Hello World";
      // Tuliskan kode untuk memverifikasi apakah input adalah palindrome
      bool? output;

      return output == false;
    },

    // Exercise 252
    () {
      String input = "Dart is Awesome";
      // Tuliskan kode untuk mengubah input menjadi huruf kecil semua dan memisahkan kata dengan spasi menjadi underscore
      String? output = "";

      return output == "dart_is_awesome";
    },

    // Exercise 253
    () {
      String input = "1234";
      // Tuliskan kode untuk memverifikasi apakah input adalah angka
      bool? output;

      return output == true;
    },

    // Exercise 254
    () {
      String input =
          "Dart is a client-optimized programming language for fast apps on multiple platforms.";
      // Tuliskan kode untuk membatasi jumlah karakter pada input menjadi 50 karakter
      String? output = "";

      return output.length == 50;
    },

    // Exercise 255
    () {
      String input =
          "Dart is a client-optimized programming language for fast apps on multiple platforms.";
      // Tuliskan kode untuk memverifikasi apakah kata "Dart" muncul pada input
      bool? output = false;
      return output == true;
    },

    // Exercise 256
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk mengecek apakah semua angka pada List numbers adalah angka genap.
      bool? output = true;
      return output == false;
    },

    // Exercise 257
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk mengecek apakah ada angka 3 pada List numbers.
      bool? output = false;
      return output;
    },

    // Exercise 258
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk menggabungkan semua angka pada List numbers menjadi satu string tanpa spasi, misalnya "12345".
      String? output = "";
      return output == "12345";
    },

    // Exercise 259
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk menggabungkan semua angka pada
      // List numbers menjadi satu string dengan spasi di antara angka,
      // misalnya "1 2 3 4 5".
      String? output = "";
      return output == "1 2 3 4 5";
    },

    // Exercise 260
    () {
      Map<String, dynamic> person = {
        "name": "John",
        "age": 30,
        "city": "New York",
      };
      // Implementasikan kode untuk mendapatkan daftar keys pada Map person.
      List<String> output = [];
      return output.contains("name") &&
          output.contains("age") &&
          output.contains("city");
    },

    // Exercise 261
    () {
      Map<String, dynamic> person = {
        "name": "John",
        "age": 30,
        "city": "New York",
      };
      // Implementasikan kode untuk mendapatkan daftar values pada Map person.
      List<dynamic> output = [];
      return output.contains("John") &&
          output.contains(30) &&
          output.contains("New York");
    },

    // Exercise 262
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk menghitung jumlah angka pada List numbers.
      int? output = -1;
      return output == 5;
    },

    // Exercise 263
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk menghitung jumlah total dari semua angka pada List numbers.
      int? output = -1;
      return output == 15;
    },

    // Exercise 264
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk menghitung jumlah total dari semua angka pada List numbers, tapi kali ini tambahkan nilai awal 10.
      int? output = -1;
      return output == 25;
    },

    // Exercise 265
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk mengambil setiap angka pada List numbers dan kalikan dengan 2, hasilnya disimpan dalam List baru.
      List<int> output = [];
      return output.contains(2) && output.contains(10) && output.length == 5;
    },

    // Exercise 266
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk mengambil setiap angka ganjil pada List numbers, hasilnya disimpan dalam List baru.
      List<int> output = [];
      return output.contains(1) &&
          output.contains(3) &&
          output.contains(5) &&
          output.length == 3;
    },

    // Exercise 267
    () {
      List<String> fruits = ["banana", "cherry", "apple"];
      // Implementasikan kode untuk mengurutkan List fruits secara ascending.
      return fruits[0] == "apple" && fruits[2] == "cherry";
    },

    // Exercise 268
    () {
      List<String> fruits = ["apple", "banana", "cherry"];
      // Implementasikan kode untuk mengurutkan List fruits secara descending.
      return fruits[0] == "cherry" && fruits[2] == "apple";
    },

    // Exercise 269
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk memeriksa apakah semua angka pada List numbers adalah angka positif (lebih besar dari 0).
      bool? output = false;
      return output;
    },

    // Exercise 270
    () {
      List<int> numbers = [-1, -2, 3, 4, 5];
      // Implementasikan kode untuk memeriksa apakah ada angka negatif pada List numbers.
      bool? output = false;
      return output;
    },

    // Exercise 271
    () {
      List<String> fruits = ["apple", "banana", "cherry"];
      // Implementasikan kode untuk memeriksa apakah ada buah dengan nama "apple" pada List fruits.
      bool? output = false;
      return output;
    },

    // Exercise 272
    () {
      List<String> fruits = ["apple", "banana", "cherry"];
      // Implementasikan kode untuk menggabungkan semua elemen pada List fruits menjadi satu string dengan spasi di antara buah-buahnya, misalnya "apple banana cherry".
      String? output = "";
      return output == "apple banana cherry";
    },

    // Exercise 273
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengubah semua karakter pada variable text menjadi huruf kecil.
      String? output = "";
      return output == "dart is awesome";
    },

    // Exercise 274
    () {
      String text = "dart is awesome";
      // Implementasikan kode untuk mengubah semua karakter pada variable text menjadi huruf besar.
      String? output = "";
      return output == "DART IS AWESOME";
    },

    // Exercise 275
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengubah karakter pertama pada variable text menjadi huruf besar.
      String? output = "";
      return output == "Dart is awesome";
    },

    // Exercise 276
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengubah karakter terakhir pada variable text menjadi huruf besar.
      String? output = "";
      return output == "Dart is awesomE";
    },

    // Exercise 277
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengganti kata "awesome" pada variable text dengan kata "fantastic".
      String? output = "";
      return output == "Dart is fantastic";
    },

    // Exercise 278
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengambil 10 karakter pertama dari variable text.
      String? output = "";
      return output == "Dart is aw";
    },

    // Exercise 279
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengambil 11 karakter terakhir dari variable text.
      String? output = "";
      return output == " is awesome";
    },

    // Exercise 280
    () {
      String text = "  Dart is awesome  ";
      // Implementasikan kode untuk menghapus spasi di awal dan akhir dari variable text.
      String? output = "";
      return output == "Dart is awesome";
    },

    // Exercise 281
    () {
      List<String> names = ["John", "Jane", "Jim", "Jack", "Jill"];
      // Implementasikan kode untuk menggabungkan semua nama pada List names menjadi satu string dengan koma di antara nama-nama tersebut, misalnya "John, Jane, Jim, Jack, Jill".
      String? output = "";
      return output == "John, Jane, Jim, Jack, Jill";
    },

    // Exercise 282
    () {
      String text = "Dart";
      // Implementasikan kode untuk membalikkan urutan karakter pada variable text, sehingga menjadi "traD".
      String? output = "";
      return output == "traD";
    },

    // Exercise 283
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk memeriksa apakah semua angka pada List numbers adalah angka positif (lebih besar dari 0).
      bool? output = false;
      return output;
    },

    // Exercise 284
    () {
      List<int> numbers = [33, 22, 13, 14, 15];
      // Implementasikan kode untuk menghitung jumlah angka pada List numbers.
      int? output = -1;
      return output == 5;
    },

    // Exercise 285
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk mengambil nilai maksimum dari List numbers.
      int? output = -1;
      return output == 5;
    },

    // Exercise 286
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk mengambil nilai minimum dari List numbers.
      int? output = -1;
      return output == 1;
    },

    // Exercise 287
    () {
      List<int> numbers = [5, 3, 2, 4, 1];
      // Implementasikan kode untuk mengurutkan List numbers secara ascending.
      return numbers[0] == 1 && numbers[4] == 5;
    },

    // Exercise 288
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk mengurutkan List numbers secara descending.
      return numbers[0] == 5 && numbers[4] == 1;
    },

    // Exercise 289
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk memeriksa apakah kata "is" muncul pada variable text.
      bool? output = false;
      return output;
    },

    // Exercise 290
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk memeriksa apakah variable text diakhiri dengan kata "awesome".
      bool? output = false;
      return output;
    },

    // Exercise 291
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk memeriksa apakah variable text diawali dengan kata "Dart".
      bool? output = false;
      return output;
    },

    // Exercise 292
    () {
      String text = "Dart,is,awesome";
      // Implementasikan kode untuk memisahkan kalimat pada variable text berdasarkan tanda koma (","), hasilnya disimpan dalam List baru.
      List<String>? output = [];
      return output.toString() == '[Dart, is, awesome]';
    },

    // Exercise 293
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengambil substring dari index 5 hingga 10 dari variable text.
      String? output = "";
      return output == "is awe";
    },

    // Exercise 294
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengambil substring dari index 5 hingga akhir dari variable text.
      String? output = "";
      return output == "is awesome";
    },

    // Exercise 295
    () {
      String text = "   Dart is awesome   ";
      // Implementasikan kode untuk menghapus spasi di awal dan akhir dari variable text.
      String? output = "";
      return output == "Dart is awesome";
    },

    // Exercise 296
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengganti kata "is" pada variable text dengan kata "will be".
      String? output = "";
      return output == "Dart will be awesome";
    },

    // Exercise 297
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengubah karakter pertama pada variable text menjadi huruf besar.
      String? output = "";
      return output == "Dart is awesome";
    },

    // Exercise 298
    () {
      String text = "dart is awesome";
      // Implementasikan kode untuk mengubah karakter pertama pada variable text menjadi huruf besar.
      String? output = "";
      return output == "Dart is awesome";
    },

    // Exercise 299
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk menghapus 3 karakter terakhir dari variable text.
      String? output = "";
      return output == "Dart is awe";
    },

    // Exercise 300
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk menambahkan karakter "!" pada akhir variable text.
      String? output = "";
      return output == "Dart is awesome!";
    },

    // Exercise 301
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengubah variable text menjadi huruf kecil semua.
      String? output = "";
      return output == "dart is awesome";
    },

    // Exercise 302
    () {
      String text = "dart is awesome";
      // Implementasikan kode untuk mengubah variable text menjadi huruf besar semua.
      String? output = "";
      return output == "DART IS AWESOME";
    },

    // Exercise 303
    () {
      String text = "dart is awesome";
      // Implementasikan kode untuk mengubah karakter pertama pada variable text menjadi huruf besar.
      String? output = "";
      return output == "Dart is awesome";
    },

    // Exercise 304
    () {
      String text = "dart is awesome";
      // Implementasikan kode untuk mengubah karakter terakhir pada variable text menjadi huruf besar.
      String? output = "";
      return output == "dart is awesomE";
    },

    // Exercise 305
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengganti kata "awesome" pada variable text dengan kata "fantastic".
      String? output = "";
      return output == "Dart is fantastic";
    },

    // Exercise 306
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengambil 10 karakter pertama dari variable text.
      String? output = "";
      return output == "Dart is aw";
    },

    // Exercise 307
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengambil 8 karakter terakhir dari variable text.
      String? output = "";
      return output == " is awesome";
    },

    // Exercise 308
    () {
      String text = "  Dart is awesome  ";
      // Implementasikan kode untuk menghapus spasi di awal dan akhir dari variable text.
      String? output = "";
      return output == "Dart is awesome";
    },

    // Exercise 309
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk memeriksa apakah kata "Dart" muncul pada variable text.
      bool? output = false;
      return output;
    },

    // Exercise 310
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk memeriksa apakah variable text mengandung huruf "a".
      bool? output = false;
      return output;
    },

    // Exercise 311
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk memeriksa apakah variable text mengandung huruf "x".
      bool? output = null;
      return output == false;
    },

    // Exercise 312
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk menghitung jumlah huruf "a" pada variable text.
      int? output = -1;
      return output == 2;
    },

    // Exercise 313
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk menghitung jumlah huruf "x" pada variable text.
      int? output = -1;
      return output == 0;
    },

    // Exercise 314
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk menghitung jumlah huruf "a" atau "A" pada variable text.
      int? output = -1;
      return output == 2;
    },

    // Exercise 315
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk memeriksa apakah variable text mengandung kata "is".
      bool? output = false;
      return output;
    },

    // Exercise 316
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk memeriksa apakah variable text diawali dengan kata "Dart" dan mengandung kata "awesome".
      bool? output = false;
      return output;
    },

    // Exercise 317
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk memeriksa apakah variable text diakhiri dengan huruf "e".
      bool? output = false;
      return output;
    },

    // Exercise 318
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk memeriksa apakah variable text mengandung huruf "x" dan "a".
      bool? output = null;
      return output == false;
    },

    // Exercise 319
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk menggabungkan variable text dengan string " and Flutter", hasilnya disimpan dalam variable baru.
      String? output = "";
      return output == "Dart is awesome and Flutter";
    },

    // Exercise 320
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk menggabungkan variable text dengan string " and Flutter" dengan menggunakan operator +=, hasilnya disimpan dalam variable baru.
      String? output = "";
      output += " and Flutter";
      return output == "Dart is awesome and Flutter";
    },

    // Exercise 321
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk menggabungkan variable text dengan string " and Flutter" dengan menggunakan method concat, hasilnya disimpan dalam variable baru.
      String? output = "";
      return output == "Dart is awesome and Flutter";
    },

    // Exercise 322
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengubah variable text menjadi list kata-kata, hasilnya disimpan dalam variable baru.
      List<String>? output = [];
      return output.toString() == '[Dart, is, awesome]';
    },

    // Exercise 323
    () {
      String text = "Awesome";
      // Implementasikan kode untuk mengubah variable text menjadi list karakter,
      // hasilnya disimpan dalam variable output.
      List<String>? output = [];
      return output.join("") == "Awesome";
    },

    // Exercise 324
    () {
      String text = "Dart is awesome";
      // Implementasikan kode untuk mengubah list kata-kata pada variable text menjadi kalimat utuh, hasilnya disimpan dalam variable baru.
      String? output = "";
      return output == "Dart is awesome";
    },

    // Exercise 325
    () {
      List<String> fruits = ["apple", "banana", "cherry"];
      // Implementasikan kode untuk menambahkan kata "orange" pada List fruits.
      return fruits.contains("orange");
    },

    // Exercise 326
    () {
      List<String> fruits = ["apple", "banana", "cherry"];
      // Implementasikan kode untuk menggabungkan dua List menjadi satu, hasilnya disimpan dalam variable baru.
      List<String>? otherFruits = ["orange", "grape"];
      List<String>? output = [];
      return output.toString() == '[apple, banana, cherry, orange, grape]';
    },

    // Exercise 327
    () {
      List<String> fruits = ["apple", "banana", "cherry"];
      // Implementasikan kode untuk menggabungkan dua List menjadi satu, hasilnya disimpan dalam List fruits.
      List<String>? otherFruits = ["orange", "grape"];
      return fruits.toString() == '[apple, banana, cherry, orange, grape]';
    },

    // Exercise 328
    () {
      List<String> fruits = ["apple", "banana", "cherry", "orange", "grape"];
      // Implementasikan kode untuk mengambil dua elemen pertama dari List fruits.
      List<String>? output = [];
      return output.toString() == '[apple, banana]';
    },

    // Exercise 329
    () {
      List<String> fruits = ["apple", "banana", "cherry", "orange", "grape"];
      // Implementasikan kode untuk menghapus dua elemen pertama dari List fruits.
      return fruits.toString() == '[cherry, orange, grape]';
    },

    // Exercise 330
    () {
      List<String> fruits = ["apple", "banana", "cherry", "orange", "grape"];
      // Implementasikan kode untuk menghapus elemen dengan nilai "cherry" dari List fruits.
      return !fruits.contains("cherry");
    },

    // Exercise 331
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk menghitung jumlah semua angka pada List numbers.
      int? output = -1;
      return output == 15;
    },

    // Exercise 332
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk menghitung hasil perkalian semua angka pada List numbers.
      int? output = -1;
      return output == 120;
    },

    // Exercise 333
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk menghitung hasil pembagian semua angka pada List numbers (dalam bentuk double).
      double? output = 0;
      return output.toStringAsFixed(2) == "3.00";
    },

    // Exercise 334
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk memeriksa apakah semua angka pada List numbers adalah angka positif (lebih besar dari 0).
      bool? output = false;
      return output;
    },

    // Exercise 335
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk memeriksa apakah setidaknya ada satu angka pada List numbers yang merupakan angka genap.
      bool? output = false;
      return output;
    },

    // Exercise 336
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk menemukan angka pertama pada List numbers yang merupakan angka genap.
      int? output = -1;
      return output == 2;
    },

    // Exercise 337
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk menemukan angka pertama pada List numbers yang merupakan angka ganjil.
      int? output = -1;
      return output == 1;
    },

    // Exercise 338
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk menemukan indeks angka pertama pada List numbers yang merupakan angka genap.
      int? output = -1;
      return output == 1;
    },

    // Exercise 339
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk menemukan indeks angka pertama pada List numbers yang merupakan angka ganjil.
      int? output = -1;
      return output == 0;
    },

    // Exercise 340
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk menghapus angka pertama pada List numbers yang merupakan angka genap.
      return !numbers.contains(2);
    },

    // Exercise 341
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk menghapus semua angka pada List numbers yang merupakan angka ganjil.
      return !numbers.contains(1) &&
          !numbers.contains(3) &&
          !numbers.contains(5);
    },

    // Exercise 342
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk mengubah semua angka pada List numbers menjadi dua kali lipatnya.
      return numbers.toString() == '[2, 4, 6, 8, 10]';
    },

    // Exercise 343
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk mengambil dua elemen terakhir dari List numbers.
      List<int>? output = [];
      return output.toString() == '[4, 5]';
    },

    // Exercise 344
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk mengambil tiga elemen pertama dari List numbers.
      List<int>? output = [];
      return output.toString() == '[1, 2, 3]';
    },

    // Exercise 345
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk mengambil tiga elemen terakhir dari List numbers.
      var output = [];
      return output.toString() == '[3, 4, 5]';
    },

    // Exercise 346
    () {
      List<int> numbers = [5, 3, 2, 1, 4];
      // Implementasikan kode untuk mengurutkan List numbers secara ascending.
      return numbers.toString() == '[1, 2, 3, 4, 5]';
    },

    // Exercise 347
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk mengurutkan List numbers secara descending.
      return numbers.toString() == '[5, 4, 3, 2, 1]';
    },

    // Exercise 348
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      // Implementasikan kode untuk menggabungkan List numbers dengan List numbers lainnya, kemudian mengurutkannya secara ascending.
      List<int>? otherNumbers = [6, 7, 8];
      List<int>? output = [];
      return output.toString() == '[1, 2, 3, 4, 5, 6, 7, 8]';
    },

    // Exercise 349
    () {
      List numbers = [10, 20, 30, 40];
      List output = [];
      // ? Instruksi:Gunakan looping for untuk menambahkan semua item dari numbers ke output
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---
      return output.toString() == "[10, 20, 30, 40]";
    },

    // Exercise 350
    () {
      List<String> fruits = ["apple", "banana", "orange"];
      List<String> output = [];

      // ? Instruksi: Gunakan looping for untuk menambahkan semua item dari fruits ke output
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return output.toString() == "[apple, banana, orange]";
    },

    // Exercise 351
    () {
      List<int> numbers = [5, 10, 15, 20];
      List<int> output = [];

      // ? Instruksi: Gunakan looping for untuk menambahkan semua item dari numbers ke output
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return output.toString() == "[5, 10, 15, 20]";
    },

    // Exercise 352
    () {
      List<String> fruits = ['apple', 'banana', 'orange', 'grape', 'kiwi'];
      bool output = false;

      // ? Instruksi: Gunakan looping for untuk mencari apakah terdapat 'kiwi' dalam list fruits
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return output == true;
    },

    // Exercise 353
    () {
      int n = 5;
      List<int> multiplesOfN = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list multiplesOfN dengan kelipatan n dari 1 hingga 5
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return multiplesOfN.toString() == "[5, 10, 15, 20, 25]";
    },

    // Exercise 354
    () {
      List<String> colors = ["red", "green", "blue"];
      String result = "";

      // ? Instruksi: Gunakan looping for untuk menggabungkan semua item dari colors menjadi satu string result
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return result == "redgreenblue";
    },

    // Exercise 355
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      int sum = 0;

      // ? Instruksi: Gunakan looping for untuk menjumlahkan semua item dari numbers ke dalam variabel sum
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return sum == 15;
    },

    // Exercise 356
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      int product = 1;

      // ? Instruksi: Gunakan looping for untuk mengalikan semua item dari numbers ke dalam variabel product
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return product == 120;
    },

    // Exercise 357
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      List<int> reversedNumbers = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list reversedNumbers dengan item dari numbers secara terbalik
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return reversedNumbers.toString() == "[5, 4, 3, 2, 1]";
    },

    // Exercise 358
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      List<int> oddNumbers = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list oddNumbers dengan item dari numbers yang merupakan bilangan ganjil
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return oddNumbers.toString() == "[1, 3, 5]";
    },

    // Exercise 359
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      int target = 3;
      bool exists = false;

      // ? Instruksi: Gunakan looping for untuk mencari apakah target ada di dalam list numbers
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return exists;
    },

    // Exercise 360
    () {
      List<int> numbers = [3, 6, 9, 12, 15];
      bool allDivisibleBy3 = false;

      // ? Instruksi: Gunakan looping for untuk mengecek apakah semua angka dalam list numbers dapat dibagi dengan 3 (hasil bagi = 0)
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---
      return allDivisibleBy3;
    },

    // Exercise 361
    () {
      List<String> fruits = ["apple", "banana", "kiwi", "orange"];
      String target = "kiwi";
      bool found = false;

      // ? Instruksi: Gunakan looping for untuk mencari apakah target ada di dalam list fruits
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return found;
    },

    // Exercise 362
    () {
      List<String> fruits = ["apple", "banana", "orange"];
      String joinedFruits = "";

      // ? Instruksi: Gunakan looping for untuk menggabungkan semua item dari list fruits menjadi satu string joinedFruits
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return joinedFruits == "applebananaorange";
    },

    // Exercise 363
    () {
      List<int> numbers = [2, 4, 6, 8, 10];
      int product = 1;

      // ? Instruksi: Gunakan looping for untuk mengalikan semua angka dalam list numbers
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return product == 3840;
    },

    // Exercise 364
    () {
      List<int> numbers = [1, 3, 5, 7, 9];
      List<int> reversedNumbers = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list reversedNumbers dengan item dari list numbers secara terbalik
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return reversedNumbers.toString() == "[9, 7, 5, 3, 1]";
    },

    // Exercise 365
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      List<int> oddNumbers = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list oddNumbers dengan item dari list numbers yang merupakan bilangan ganjil
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return oddNumbers.toString() == "[1, 3, 5]";
    },

    // Exercise 366
    () {
      List<int> sales = [100, 200, 300, 400, 500];
      int salesTotal = 0;

      // ? Instruksi: Gunakan looping for untuk menghitung total penjualan (salesTotal) dari list sales
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return salesTotal == 1500;
    },

    // Exercise 367
    () {
      List<int> sales = [100, 200, 300, 400, 500];
      double salesAverage = 0;

      // ? Instruksi: Gunakan looping for untuk menghitung rata-rata penjualan (salesAverage) dari list sales
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return salesAverage == 300;
    },

    // Exercise 368
    () {
      List<int> productPrices = [1000, 2000, 1500, 3000, 500];
      int cheapestProduct = 0;

      // ? Instruksi: Gunakan looping for untuk mencari harga produk termurah (cheapestProduct) dari list productPrices
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return cheapestProduct == 500;
    },

    // Exercise 369
    () {
      List<int> productPrices = [1000, 2000, 1500, 3000, 500];
      int expensiveProduct = 0;

      // ? Instruksi: Gunakan looping for untuk mencari harga produk termahal (expensiveProduct) dari list productPrices
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return expensiveProduct == 3000;
    },

    // Exercise 370
    () {
      List<String> products = [
        "apple",
        "banana",
        "orange",
        "banana",
        "apple",
        "banana"
      ];
      String favoriteProduct = "";

      // ? Instruksi: Gunakan looping for untuk mencari produk favorit (favoriteProduct) yang paling sering muncul dalam list products
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return favoriteProduct == "banana";
    },

    // Exercise 371
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      List<int> squaredNumbers = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list squaredNumbers dengan nilai kuadrat dari setiap angka dalam list numbers
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return squaredNumbers.toString() == "[1, 4, 9, 16, 25]";
    },

    // Exercise 372
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      List<int> evenNumbers = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list evenNumbers dengan angka genap dari list numbers
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return evenNumbers.toString() == "[2, 4]";
    },

    // Exercise 373
    () {
      List<int> numbers = [1, 2, 3, 4, 5];
      List<int> oddNumbers = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list oddNumbers dengan angka ganjil dari list numbers
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return oddNumbers.toString() == "[1, 3, 5]";
    },

    // Exercise 374
    () {
      List<String> fruits = ["apple", "banana", "orange"];
      List<String> capitalizedFruits = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list capitalizedFruits dengan semua item dari list fruits yang telah dijadikan huruf kapital
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return capitalizedFruits.toString() == "[APPLE, BANANA, ORANGE]";
    },

    // Exercise 375
    () {
      List<String> names = ["Alice", "Bob", "Charlie", "David"];
      String concatenatedNames = "";

      // ? Instruksi: Gunakan looping for untuk menggabungkan semua item dari list names menjadi satu string concatenatedNames, dipisahkan oleh koma
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---
      return concatenatedNames == "Alice,Bob,Charlie,David";
    },

    // Exercise 376
    () {
      List<int> numbers = [5, 2, 7, 3, 1];
      List<int> sortedNumbers = [];

      // ? Isi list 'sortedNumbers' dengan angka-angka yang telah diurutkan secara descending.
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return sortedNumbers.toString() == "[7, 5, 3, 2, 1]";
    },

    // Exercise 377
    () {
      List<String> fruits = ["apple", "orange", "banana", "kiwi", "mango"];
      List<String> filteredFruits = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list filteredFruits dengan nama-nama buah yang memiliki huruf 'a' di dalamnya.
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return filteredFruits.toString() == "[apple, orange, banana, mango]";
    },

    // Exercise 378
    () {
      List<int> numbers = [7, 2, 5, 3, 1];
      int sum = 0;

      // ? Instruksi: Gunakan looping for untuk menjumlahkan semua item dari numbers ke dalam variabel sum, tetapi berhenti jika jumlahnya mencapai 10.
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return sum == 9;
    },

    // Exercise 379
    () {
      List<int> numbers = [5, 2, 7, 3, 1];
      List<int> reversedNumbers = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list reversedNumbers dengan item dari numbers secara terbalik
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return reversedNumbers.toString() == "[1, 3, 7, 2, 5]";
    },

    // Exercise 380
    () {
      List<String> words = ["apple", "orange", "banana", "kiwi", "mango"];
      String concatenatedWords = "";

      // ? Instruksi: Gunakan looping for untuk menggabungkan semua item dari list words menjadi satu string concatenatedWords, dipisahkan oleh spasi.
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return concatenatedWords == "apple orange banana kiwi mango ";
    },

    // Exercise 381
    () {
      List<int> numbers = [5, 2, 7, 3, 1];
      List<int> squaredNumbers = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list squaredNumbers dengan hasil kuadrat dari setiap angka dalam list numbers.
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return squaredNumbers.toString() == "[25, 4, 49, 9, 1]";
    },

    // Exercise 382
    () {
      List<int> numbers = [5, 2, 7, 3, 1];
      int minValue = numbers[0];

      // ? Instruksi: Gunakan looping for untuk mencari nilai terkecil (minimum) dalam list numbers dan simpan dalam variabel minValue.
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return minValue == 1;
    },

    // Exercise 383
    () {
      List<int> numbers = [5, 2, 7, 3, 1];
      int maxValue = numbers[0];

      // ? Instruksi: Gunakan looping for untuk mencari nilai terbesar (maximum) dalam list numbers dan simpan dalam variabel maxValue.
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return maxValue == 7;
    },

    // Exercise 384
    () {
      List<int> numbers = [5, 2, 7, 3, 1];
      List<int> evenNumbers = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list evenNumbers dengan angka-angka genap dari list numbers.
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return evenNumbers.toString() == "[2]";
    },

    // Exercise 385
    () {
      List<int> numbers = [5, 2, 7, 3, 1];
      List<int> evenNumbers = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list evenNumbers
      // dengan angka-angka genap dari list numbers.
      // Kalikan angka genap itu dengan 9
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return evenNumbers.toString() == "[18]";
    },

    // Exercise 386
    () {
      List<Map> users = [
        {
          "id": 1,
          "name": "Alex",
          "age": 29,
        },
        {
          "id": 2,
          "name": "David",
          "age": 31,
        },
        {
          "id": 3,
          "name": "Siren",
          "age": 28,
        }
      ];
      List<Map> filteredUsers = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list filteredUsers dengan ketentuan User yang huruf depannya adalah A
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return filteredUsers.isNotEmpty && filteredUsers[0]["id"] == 1;
    },

    // Exercise 387
    () {
      List<Map<String, dynamic>> users = [
        {
          "id": 1,
          "name": "Alex",
          "age": 29,
        },
        {
          "id": 2,
          "name": "David",
          "age": 31,
        },
        {
          "id": 3,
          "name": "Siren",
          "age": 28,
        }
      ];

      List<Map<String, dynamic>> filteredUsers = [];
      // Instruksi: Gunakan looping for untuk mengisi list filteredUsers dengan ketentuan User yang huruf depannya adalah "D"
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return filteredUsers.isNotEmpty && filteredUsers[0]["id"] == 2;
    },

    // Exercise 388
    () {
      List<Map<String, dynamic>> users = [
        {
          "id": 1,
          "name": "Alex",
          "age": 29,
        },
        {
          "id": 2,
          "name": "David",
          "age": 31,
        },
        {
          "id": 3,
          "name": "Siren",
          "age": 28,
        }
      ];
      List<Map<String, dynamic>> filteredUsers = [];

      // Instruksi: Gunakan looping for untuk mengisi list filteredUsers dengan ketentuan User yang usianya di atas 30 tahun
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return filteredUsers.isNotEmpty && filteredUsers[0]["id"] == 2;
    },

    // Exercise 389
    () {
      List<Map<String, dynamic>> users = [
        {
          "id": 1,
          "name": "Alex",
          "age": 29,
        },
        {
          "id": 2,
          "name": "David",
          "age": 31,
        },
        {
          "id": 3,
          "name": "Siren",
          "age": 28,
        }
      ];
      List<String> names = [];

      // Instruksi: Gunakan looping for untuk mengisi list names dengan semua nama dari users
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return names.isNotEmpty && names.length == 3;
    },

    // Exercise 390
    () {
      List<Map<String, dynamic>> users = [
        {
          "id": 1,
          "name": "Alex",
          "age": 29,
        },
        {
          "id": 2,
          "name": "David",
          "age": 31,
        },
        {
          "id": 3,
          "name": "Siren",
          "age": 28,
        }
      ];
      int age = -1;

      // Instruksi: Gunakan looping for untuk mencari user dengan id = 2 dan kembalikan nilai usianya
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return age == 31;
    },

    // Exercise 391
    () {
      List<Map<String, dynamic>> users = [
        {
          "id": 1,
          "name": "Alex",
          "age": 29,
        },
        {
          "id": 2,
          "name": "David",
          "age": 31,
        },
        {
          "id": 3,
          "name": "Siren",
          "age": 28,
        }
      ];
      bool containsId3 = false;

      // Instruksi: Gunakan looping for untuk mengecek apakah users mengandung user dengan id = 3
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return containsId3;
    },

    // Exercise 392
    () {
      List<Map<String, dynamic>> users = [
        {
          "id": 1,
          "name": "Alex",
          "age": 29,
        },
        {
          "id": 2,
          "name": "David",
          "age": 31,
        },
        {
          "id": 3,
          "name": "Siren",
          "age": 28,
        }
      ];
      List<Map<String, dynamic>> updatedUsers = [];

      // Instruksi: Gunakan looping for untuk mengupdate usia setiap user menjadi usia + 1 dan masukkan ke dalam list updatedUsers
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return updatedUsers.isNotEmpty && updatedUsers[0]["age"] == 30;
    },

    // Exercise 393
    () {
      List<Map<String, dynamic>> users = [
        {
          "id": 1,
          "name": "Alex",
          "age": 29,
        },
        {
          "id": 2,
          "name": "David",
          "age": 31,
        },
        {
          "id": 3,
          "name": "Siren",
          "age": 28,
          "address": "Ciawi street",
        }
      ];
      List<Map<String, dynamic>> filteredUsers = [];

      // Instruksi: Gunakan looping for untuk mengisi list filteredUsers dengan user yang memiliki properti "address"
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return filteredUsers.isNotEmpty && filteredUsers[0]["id"] == 3;
    },

    // Exercise 394
    () {
      List<Map<String, dynamic>> users = [
        {
          "id": 1,
          "name": "Alex",
          "age": 29,
        },
        {
          "id": 2,
          "name": "David",
          "age": 31,
        },
        {
          "id": 3,
          "name": "Siren",
          "age": 28,
        }
      ];
      List<String> names = [];

      // Instruksi: Gunakan looping for untuk mengisi list names dengan nama-nama user yang usianya kurang dari 30 tahun
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return names.isNotEmpty && names.length == 2;
    },

    // Exercise 395
    () {
      List<Map<String, dynamic>> users = [
        {
          "id": 1,
          "name": "Alex",
          "age": 29,
        },
        {
          "id": 2,
          "name": "David",
          "age": 31,
        },
        {
          "id": 3,
          "name": "Siren",
          "age": 28,
        }
      ];

      // Instruksi: Gunakan looping for untuk mencari user dengan id = 3 dan hapus user tersebut dari list users
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return users.length == 2 && users[1]["name"] == "David";
    },

    // Exercise 396
    () {
      List<Map<String, dynamic>> data = [
        {"transaction": "Sale", "amount": 1000},
        {"transaction": "Refund", "amount": -200},
        {"transaction": "Sale", "amount": 500},
        {"transaction": "Sale", "amount": 800},
      ];
      int totalSales = 0;

      // Instruksi: Gunakan looping for untuk menghitung total penjualan (amount positif) dari data transaksi
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return totalSales == 2300;
    },

    // Exercise 397
    () {
      List<Map<String, dynamic>> data = [
        {"transaction": "Sale", "amount": 1000},
        {"transaction": "Refund", "amount": -200},
        {"transaction": "Sale", "amount": 500},
        {"transaction": "Sale", "amount": 800},
      ];
      int totalRefunds = 0;

      // Instruksi: Gunakan looping for untuk menghitung total refund (amount negatif) dari data transaksi
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return totalRefunds == 200;
    },

    // Exercise 398
    () {
      List<Map<String, dynamic>> data = [
        {"transaction": "Sale", "amount": 1000, "isPromo": false},
        {"transaction": "Refund", "amount": -200, "isPromo": false},
        {"transaction": "Sale", "amount": 500, "isPromo": true},
        {"transaction": "Sale", "amount": 800, "isPromo": false},
      ];
      int totalPromoSales = 0;

      // Instruksi: Gunakan looping for untuk menghitung total penjualan dengan isPromo true dari data transaksi
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return totalPromoSales == 500;
    },

    // Exercise 399
    () {
      List<Map<String, dynamic>> data = [
        {"transaction": "Sale", "amount": 1000, "category": "Electronics"},
        {"transaction": "Refund", "amount": -200, "category": "Fashion"},
        {"transaction": "Sale", "amount": 500, "category": "Electronics"},
        {"transaction": "Sale", "amount": 800, "category": "Fashion"},
      ];
      int totalElectronicsSales = 0;

      // Instruksi: Gunakan looping for untuk menghitung total penjualan kategori "Electronics" dari data transaksi
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return totalElectronicsSales == 1500;
    },

    // Exercise 400
    () {
      List<Map<String, dynamic>> data = [
        {"transaction": "Sale", "amount": 1000, "category": "Electronics"},
        {"transaction": "Refund", "amount": 200, "category": "Fashion"},
        {"transaction": "Sale", "amount": 500, "category": "Electronics"},
        {"transaction": "Sale", "amount": 800, "category": "Fashion"},
      ];
      int totalFashionRefunds = 0;

      // Instruksi: Gunakan looping for untuk menghitung total refund kategori "Fashion" dari data transaksi
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return totalFashionRefunds == 200;
    },

    // Exercise 401
    () {
      List<Map<String, dynamic>> data = [
        {"transaction": "Sale", "amount": 1000, "category": "Electronics"},
        {"transaction": "Refund", "amount": -200, "category": "Fashion"},
        {"transaction": "Sale", "amount": 500, "category": "Electronics"},
        {"transaction": "Sale", "amount": 800, "category": "Fashion"},
      ];
      int totalSalesInElectronics = 0;

      // Instruksi: Gunakan looping for untuk menghitung total penjualan kategori "Electronics" dari data transaksi
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return totalSalesInElectronics == 1500;
    },

    // Exercise 402
    () {
      List<Map<String, dynamic>> data = [
        {"transaction": "Sale", "amount": 1000, "category": "Electronics"},
        {"transaction": "Refund", "amount": -200, "category": "Fashion"},
        {"transaction": "Sale", "amount": 500, "category": "Electronics"},
        {"transaction": "Sale", "amount": 800, "category": "Fashion"},
      ];
      int totalSales = 0;
      int totalRefunds = 0;

      // Instruksi: Gunakan looping for untuk menghitung total penjualan dan refund dari data transaksi
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return totalSales == 2300 && totalRefunds == 200;
    },

    // Exercise 403
    () {
      List<Map<String, dynamic>> data = [
        {"name": "John", "hoursWorked": 40, "hourlyRate": 20},
        {"name": "Alice", "hoursWorked": 30, "hourlyRate": 25},
        {"name": "Bob", "hoursWorked": 20, "hourlyRate": 30},
      ];
      int totalSalary = 0;

      // Instruksi: Gunakan looping for untuk menghitung total gaji (hoursWorked * hourlyRate) dari data karyawan
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---
      return totalSalary == 2150;
    },

    // Exercise 404
    () {
      List<Map<String, dynamic>> data = [
        {"name": "John", "hoursWorked": 40, "hourlyRate": 20},
        {"name": "Alice", "hoursWorked": 30, "hourlyRate": 25},
        {"name": "Bob", "hoursWorked": 20, "hourlyRate": 30},
      ];
      int maxHourlyRate = 0;

      // Instruksi: Gunakan looping for untuk mencari nilai maksimum dari "hourlyRate" pada data karyawan
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return maxHourlyRate == 30;
    },

    // Exercise 405
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard", "price": 250000},
        {"id": 2, "name": "Mouse", "price": 150000},
        {"id": 3, "name": "Headphones", "price": 350000},
      ];
      double totalHarga = 0;

      // ? Instruksi: Gunakan looping for untuk menghitung total harga dari semua produk di dalam list products
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return totalHarga == 750000;
    },

    // Exercise 406
    () {
      List<Map<String, dynamic>> transactions = [
        {"id": 1, "amount": 3, "price": 50000},
        {"id": 2, "amount": 1, "price": 75000},
        {"id": 3, "amount": 5, "price": 30000},
      ];
      double totalPendapatan = 0;

      // ? Instruksi: Gunakan looping for untuk menghitung total pendapatan dari semua transaksi di dalam list transactions
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return totalPendapatan == 375000;
    },

    // Exercise 407
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John", "salary": 5000000},
        {"id": 2, "name": "Alice", "salary": 6000000},
        {"id": 3, "name": "Bob", "salary": 4500000},
      ];
      double totalGaji = 0;

      // ? Instruksi: Gunakan looping for untuk menghitung total gaji dari semua karyawan di dalam list employees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      double rataRataGaji = totalGaji / employees.length;

      return rataRataGaji == 5166666.666666667;
    },

    // Exercise 408
    () {
      List<Map<String, dynamic>> orders = [
        {"id": 1, "product": "Keyboard", "quantity": 2, "price": 250000},
        {"id": 2, "product": "Mouse", "quantity": 3, "price": 150000},
        {"id": 3, "product": "Headphones", "quantity": 1, "price": 350000},
      ];
      double totalNilaiPemesanan = 0;

      // ? Instruksi: Gunakan looping for untuk menghitung total nilai pemesanan dari semua orders di dalam list orders
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return totalNilaiPemesanan == 1300000.0;
    },

    // Exercise 409
    () {
      List<Map<String, dynamic>> shipments = [
        {"id": 1, "product": "Keyboard", "quantity": 2, "shippingCost": 20000},
        {"id": 2, "product": "Mouse", "quantity": 3, "shippingCost": 18000},
        {
          "id": 3,
          "product": "Headphones",
          "quantity": 1,
          "shippingCost": 25000
        },
      ];
      int maxBiayaPengiriman = 0;

      // ? Instruksi: Gunakan looping for untuk mencari nilai tertinggi dari shippingCost di dalam list shipments
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return maxBiayaPengiriman == 25000;
    },

    // Exercise 410
    () {
      List<Map<String, dynamic>> attendance = [
        {"id": 1, "name": "John", "isPresent": true},
        {"id": 2, "name": "Alice", "isPresent": false},
        {"id": 3, "name": "Bob", "isPresent": true},
        {"id": 4, "name": "Eve", "isPresent": false},
      ];
      int jumlahHadir = 0;

      // ? Instruksi: Gunakan looping for untuk menghitung jumlah kehadiran (isPresent = true) di dalam list attendance
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return jumlahHadir == 2;
    },

    // Exercise 411
    () {
      List<Map<String, dynamic>> warehouse = [
        {"id": 1, "product": "Keyboard", "stock": 50},
        {"id": 2, "product": "Mouse", "stock": 30},
        {"id": 3, "product": "Headphones", "stock": 20},
      ];
      int maxStok = 0;

      // ? Instruksi: Gunakan looping for untuk mencari nilai tertinggi dari stock di dalam list warehouse
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return maxStok == 50;
    },

    // Exercise 412
    () {
      List<Map<String, dynamic>> projectTasks = [
        {"id": 1, "task": "Design", "progress": 100},
        {"id": 2, "task": "Development", "progress": 75},
        {"id": 3, "task": "Testing", "progress": 50},
      ];
      int jumlahSelesai = 0;

      // ? Instruksi: Gunakan looping for untuk menghitung jumlah tugas yang telah selesai (progress = 100) di dalam list projectTasks
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return jumlahSelesai == 1;
    },

    // Exercise 413
    () {
      List<Map<String, dynamic>> employeeAttendance = [
        {"id": 1, "name": "John", "isPresent": true},
        {"id": 2, "name": "Alice", "isPresent": false},
        {"id": 3, "name": "Bob", "isPresent": true},
        {"id": 4, "name": "Eve", "isPresent": false},
      ];
      List<Map<String, dynamic>> hadirOnly = [];

      // ? Instruksi: Gunakan looping for untuk mengisi list hadirOnly dengan data karyawan yang hadir (isPresent = true)
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return hadirOnly.length == 2;
    },

    // Exercise 414
    () {
      List<Map<String, dynamic>> studentScores = [
        {"id": 1, "name": "John", "score": 85},
        {"id": 2, "name": "Alice", "score": 92},
        {"id": 3, "name": "Bob", "score": 78},
        {"id": 4, "name": "Eve", "score": 88},
      ];
      double totalScore = 0;

      // ? Instruksi: Gunakan looping for untuk menghitung total nilai dari semua siswa di dalam list studentScores
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      double averageScore = totalScore / studentScores.length;

      return averageScore == 85.75;
    },

    // Exercise 415
    () {
      List<Map<String, dynamic>> sales = [
        {"id": 1, "product": "Keyboard", "quantitySold": 100, "price": 250000},
        {"id": 2, "product": "Mouse", "quantitySold": 50, "price": 150000},
        {"id": 3, "product": "Monitor", "quantitySold": 30, "price": 1000000},
      ];
      double totalSales = 0;

      // ? Instruksi: Gunakan looping for untuk menghitung total penjualan (quantitySold) dari semua produk di dalam list sales
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return totalSales == 180;
    },

    // Exercise 416
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John", "age": 30, "salary": 5000000},
        {"id": 2, "name": "Alice", "age": 25, "salary": 6000000},
        {"id": 3, "name": "Bob", "age": 35, "salary": 4500000},
      ];
      double totalSalary = 0;

      // ? Instruksi: Gunakan looping for untuk menghitung total gaji (salary) dari semua karyawan di dalam list employees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return totalSalary == 15500000;
    },

    // Exercise 417
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John", "age": 30, "salary": 5000000},
        {"id": 2, "name": "Alice", "age": 25, "salary": 6000000},
        {"id": 3, "name": "Bob", "age": 35, "salary": 4500000},
      ];
      double averageAge = 0;

      // ? Instruksi: Gunakan looping for untuk menghitung rata-rata usia (age) dari semua karyawan di dalam list employees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return averageAge == 30.0;
    },

    // Exercise 418
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard", "price": 250000, "quantitySold": 100},
        {"id": 2, "name": "Mouse", "price": 150000, "quantitySold": 50},
        {"id": 3, "name": "Headphones", "price": 350000, "quantitySold": 75},
      ];
      int maxPrice = 0;
      int minPrice = products[0]["price"];

      // ? Instruksi: Gunakan looping for untuk mencari harga termahal dan harga termurah dari semua produk di dalam list products
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return maxPrice == 350000 && minPrice == 150000;
    },

    // Exercise 419
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard", "quantitySold": 100},
        {"id": 2, "name": "Mouse", "quantitySold": 50},
        {"id": 3, "name": "Headphones", "quantitySold": 75},
      ];
      String bestProduct = "";
      int maxQuantitySold = 0;

      // ? Instruksi: Gunakan looping for untuk mencari produk terlaris (dengan quantitySold terbanyak) di dalam list products
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return bestProduct == "Keyboard";
    },

    // Exercise 420
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John", "kpi": 90},
        {"id": 2, "name": "Alice", "kpi": 80},
        {"id": 3, "name": "Bob", "kpi": 70},
      ];
      String bestEmployee = "";
      int maxKpi = 0;

      // ? Instruksi: Gunakan looping for untuk mencari karyawan terbaik (dengan KPI tertinggi) di dalam list employees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return bestEmployee == "John";
    },

    // Exercise 421
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John", "kpi": 90},
        {"id": 2, "name": "Alice", "kpi": 80},
        {"id": 3, "name": "Bob", "kpi": 70},
      ];
      List<String> lowPerformers = [];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan dengan KPI rendah (kurang dari 80) di dalam list employees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return lowPerformers.contains("Bob");
    },

    // Exercise 422
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John", "kpi": 90},
        {"id": 2, "name": "Alice", "kpi": 80},
        {"id": 3, "name": "Bob", "kpi": 70},
      ];
      double totalKpi = 0;

      // ? Instruksi: Gunakan looping for untuk menghitung total KPI dari semua karyawan di dalam list employees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      double averageKpi = totalKpi / employees.length;
      return averageKpi == 80.0;
    },
    // Exercise 423
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard", "price": 250000, "quantitySold": 100},
        {"id": 2, "name": "Mouse", "price": 150000, "quantitySold": 50},
        {"id": 3, "name": "Headphones", "price": 350000, "quantitySold": 75},
      ];

      int maxPrice = 0;
      int minPrice = 0;

      // ? Instruksi: Gunakan looping for untuk mencari harga termahal dan harga termurah dari semua produk di dalam list products
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return maxPrice == 350000 && minPrice == 150000;
    },

    // Exercise 424
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard", "quantitySold": 100},
        {"id": 2, "name": "Mouse", "quantitySold": 50},
        {"id": 3, "name": "Headphones", "quantitySold": 75},
      ];
      String bestProduct = "";
      int maxQuantitySold = 0;

      // ? Instruksi: Gunakan looping for untuk mencari produk terlaris (dengan quantitySold terbanyak) di dalam list products
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return bestProduct == "Keyboard";
    },

    // Exercise 425
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John", "kpi": 90, "absentDays": 3},
        {"id": 2, "name": "Alice", "kpi": 80, "absentDays": 5},
        {"id": 3, "name": "Bob", "kpi": 70, "absentDays": 1},
      ];
      String bestEmployee = "";
      int minAbsentDays = employees[0]["absentDays"];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan dengan absensi bagus (sedikit absentDays) di dalam list employees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return bestEmployee == "Bob";
    },

    // Exercise 426
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard", "quantitySold": 100, "soldInDays": 10},
        {"id": 2, "name": "Mouse", "quantitySold": 50, "soldInDays": 5},
        {"id": 3, "name": "Headphones", "quantitySold": 75, "soldInDays": 15},
      ];
      String bestProduct = "";
      int maxSoldInDays = 0;

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan penjualan tercepat (dengan soldInDays terbanyak) di dalam list products
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return bestProduct == "Headphones";
    },

    // Exercise 427
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John", "kpi": 90, "absentDays": 3},
        {"id": 2, "name": "Alice", "kpi": 80, "absentDays": 5},
        {"id": 3, "name": "Bob", "kpi": 70, "absentDays": 1},
      ];
      List<String> highPerformers = [];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan dengan KPI tinggi (lebih dari 80) di dalam list employees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return highPerformers.contains("John");
    },

    // Exercise 428
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard", "quantitySold": 100, "soldInDays": 10},
        {"id": 2, "name": "Mouse", "quantitySold": 50, "soldInDays": 5},
        {"id": 3, "name": "Headphones", "quantitySold": 75, "soldInDays": 15},
      ];
      List<String> bestProducts = [];
      int maxSoldInDays = 0;

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan penjualan tercepat (dengan soldInDays terbanyak) di dalam list products
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return bestProducts.length == 1 && bestProducts.contains("Headphones");
    },

    // Exercise 429
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John", "kpi": 90, "absentDays": 3},
        {"id": 2, "name": "Alice", "kpi": 80, "absentDays": 5},
        {"id": 3, "name": "Bob", "kpi": 120, "absentDays": 1},
      ];
      List<Map<String, dynamic>> highPerformers = [];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan dengan KPI tinggi (lebih dari 80) di dalam list employees
      // Kemudian masukkan data karyawan tersebut ke dalam list highPerformers
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return highPerformers.length == 2 &&
          highPerformers[0]["name"] == "John" &&
          highPerformers[1]["name"] == "Bob";
    },

    // Exercise 430
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John", "kpi": 90, "absentDays": 3},
        {"id": 2, "name": "Alice", "kpi": 80, "absentDays": 5},
        {"id": 3, "name": "Bob", "kpi": 70, "absentDays": 1},
      ];
      List<Map<String, dynamic>> lowPerformers = [];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan dengan KPI rendah (kurang dari 80) di dalam list employees
      // Kemudian masukkan data karyawan tersebut ke dalam list lowPerformers
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return lowPerformers.length == 1 && lowPerformers[0]["name"] == "Bob";
    },

    // Exercise 431
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard", "quantitySold": 100, "soldInDays": 10},
        {"id": 2, "name": "Mouse", "quantitySold": 50, "soldInDays": 5},
        {"id": 3, "name": "Headphones", "quantitySold": 75, "soldInDays": 15},
      ];
      List<Map<String, dynamic>> bestProducts = [];
      int maxSoldInDays = 0;

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan penjualan tercepat (dengan soldInDays terbanyak) di dalam list products
      // Kemudian masukkan data produk tersebut ke dalam list bestProducts
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return bestProducts.length == 1 &&
          bestProducts[0]["name"] == "Headphones";
    },

    // Exercise 432
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John", "kpi": 90, "absentDays": 3},
        {"id": 2, "name": "Alice", "kpi": 80, "absentDays": 5},
        {"id": 3, "name": "Bob", "kpi": 70, "absentDays": 1},
      ];
      List<Map<String, dynamic>> goodPerformers = [];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan dengan absensi bagus (sedikit absentDays) di dalam list employees
      // Kemudian masukkan data karyawan tersebut ke dalam list goodPerformers
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return goodPerformers.length == 1 && goodPerformers[0]["name"] == "Bob";
    },

    // Exercise 433
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard", "quantitySold": 100, "soldInDays": 10},
        {"id": 2, "name": "Mouse", "quantitySold": 50, "soldInDays": 5},
        {"id": 3, "name": "Headphones", "quantitySold": 75, "soldInDays": 15},
      ];
      List<Map<String, dynamic>> bestProducts = [];
      int maxSoldInDays = 0;

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan penjualan tercepat (dengan soldInDays terbanyak) di dalam list products
      // Kemudian masukkan data produk tersebut ke dalam list bestProducts
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return bestProducts.length == 1 &&
          bestProducts[0]["name"] == "Headphones";
    },
    // Exercise 434
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John", "age": 28, "department": "HR"},
        {"id": 2, "name": "Alice", "age": 32, "department": "Finance"},
        {"id": 3, "name": "Bob", "age": 25, "department": "IT"},
      ];
      List<String> hrEmployees = [];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan yang bekerja di departemen "HR"
      // Kemudian masukkan nama karyawan tersebut ke dalam list hrEmployees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return hrEmployees.length == 1 && hrEmployees.contains("John");
    },

    // Exercise 435
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard", "price": 250000, "quantity": 50},
        {"id": 2, "name": "Mouse", "price": 150000, "quantity": 100},
        {"id": 3, "name": "Headphones", "price": 350000, "quantity": 75},
      ];
      List<String> expensiveProducts = [];

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan harga lebih dari 200000
      // Kemudian masukkan nama produk tersebut ke dalam list expensiveProducts
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return expensiveProducts.length == 2 &&
          expensiveProducts.contains("Keyboard") &&
          expensiveProducts.contains("Headphones");
    },

    // Exercise 436
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard", "price": 250000, "quantity": 50},
        {"id": 2, "name": "Mouse", "price": 150000, "quantity": 100},
        {"id": 3, "name": "Headphones", "price": 350000, "quantity": 75},
      ];
      List<String> affordableProducts = [];

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan harga kurang dari 300000
      // Kemudian masukkan nama produk tersebut ke dalam list affordableProducts
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return affordableProducts.length == 2 &&
          affordableProducts.contains("Keyboard") &&
          affordableProducts.contains("Mouse");
    },

    // Exercise 437
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John", "age": 28, "department": "HR"},
        {"id": 2, "name": "Alice", "age": 32, "department": "Finance"},
        {"id": 3, "name": "Bob", "age": 25, "department": "IT"},
      ];
      String hrEmployee = "";

      // ? Instruksi: Gunakan looping for untuk mencari karyawan yang bekerja di departemen "HR"
      // Jika ditemukan, simpan nama karyawan tersebut pada variabel hrEmployee
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return hrEmployee == "John";
    },

    // Exercise 438
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard", "price": 250000, "quantity": 50},
        {"id": 2, "name": "Mouse", "price": 150000, "quantity": 100},
        {"id": 3, "name": "Headphones", "price": 350000, "quantity": 75},
      ];
      String expensiveProduct = "";

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan harga lebih dari 300000
      // Jika ditemukan, simpan nama produk tersebut pada variabel expensiveProduct
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return expensiveProduct == "Headphones";
    },

    // Exercise 439
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John", "age": 28, "department": "HR"},
        {"id": 2, "name": "Alice", "age": 32, "department": "Finance"},
        {"id": 3, "name": "Bob", "age": 25, "department": "IT"},
      ];
      List<String> itEmployees = [];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan yang bekerja di departemen "IT"
      // Kemudian masukkan nama karyawan tersebut ke dalam list itEmployees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return itEmployees.length == 1 && itEmployees.contains("Bob");
    },

    // Exercise 440
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard", "price": 250000, "quantity": 50},
        {"id": 2, "name": "Mouse", "price": 150000, "quantity": 100},
        {"id": 3, "name": "Headphones", "price": 350000, "quantity": 75},
      ];
      List<String> affordableProducts = [];

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan harga kurang dari 200000
      // Kemudian masukkan nama produk tersebut ke dalam list affordableProducts
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return affordableProducts.length == 1 &&
          affordableProducts.contains("Mouse");
    },

    // Exercise 441
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John", "age": 28, "gender": "Male"},
        {"id": 2, "name": "Alice", "age": 32, "gender": "Female"},
        {"id": 3, "name": "Bob", "age": 25, "gender": "Male"},
      ];
      String name = "";
      int age = 0;
      String gender = "";

      // ? Instruksi: Gunakan looping for untuk mencari karyawan dengan usia lebih dari 30 tahun atau berjenis kelamin "Female"
      // Jika ditemukan, simpan nama, usia, dan jenis kelaminnya pada variabel yang telah disediakan
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return name == "Alice" && age == 32 && gender == "Female";
    },

    // Exercise 442
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard", "price": 250000, "quantitySold": 40},
        {"id": 2, "name": "Mouse", "price": 150000, "quantitySold": 50},
        {"id": 3, "name": "Headphones", "price": 350000, "quantitySold": 30},
      ];
      List<Map<String, dynamic>> matchedProducts = [];

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan harga lebih dari 200000 dan terjual kurang dari 60
      // Kemudian masukkan data produk tersebut ke dalam list matchedProducts
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedProducts.isNotEmpty && matchedProducts.first["id"] == 1;
    },

    // Exercise 443
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John Doe", "age": 28},
        {"id": 2, "name": "Alice Smith", "age": 32},
        {"id": 3, "name": "Bob Johnson", "age": 25},
      ];
      List<Map<String, dynamic>> matchedEmployees = [];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan dengan nama mengandung huruf "Do"
      // Kemudian masukkan data karyawan tersebut ke dalam list matchedEmployees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedEmployees.length == 1 &&
          matchedEmployees[0]["name"] == "John Doe";
    },

    // Exercise 444
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard Logitech", "price": 250000},
        {"id": 2, "name": "Mouse Logitech", "price": 150000},
        {"id": 3, "name": "Headphones Sony", "price": 350000},
      ];
      List<Map<String, dynamic>> matchedProducts = [];

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan nama mengandung huruf "Sony"
      // Kemudian masukkan data produk tersebut ke dalam list matchedProducts
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedProducts.length == 1 &&
          matchedProducts[0]["name"] == "Headphones Sony";
    },

    // Exercise 445
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John Doe", "age": 28},
        {"id": 2, "name": "Alice Smith", "age": 32},
        {"id": 3, "name": "Bob Johnson", "age": 25},
      ];
      List<Map<String, dynamic>> matchedEmployees = [];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan dengan nama depan mengandung huruf "Jo"
      // Kemudian masukkan data karyawan tersebut ke dalam list matchedEmployees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedEmployees.length == 1 &&
          matchedEmployees[0]["name"] == "John Doe";
    },

    // Exercise 446
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard Logitech", "price": 250000},
        {"id": 2, "name": "Mouse Logitech", "price": 150000},
        {"id": 3, "name": "Headphones Sony", "price": 350000},
      ];
      List<Map<String, dynamic>> matchedProducts = [];

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan nama mengandung huruf "Logi"
      // Kemudian masukkan data produk tersebut ke dalam list matchedProducts
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedProducts.length == 2 &&
          matchedProducts[0]["name"] == "Keyboard Logitech" &&
          matchedProducts[1]["name"] == "Mouse Logitech";
    },

    // Exercise 447
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John Doe", "age": 28},
        {"id": 2, "name": "Alice Smith", "age": 32},
        {"id": 3, "name": "Bob Johnson", "age": 25},
      ];
      List<Map<String, dynamic>> matchedEmployees = [];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan dengan nama belakang mengandung huruf "son"
      // Kemudian masukkan data karyawan tersebut ke dalam list matchedEmployees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedEmployees.length == 1 &&
          matchedEmployees[0]["name"] == "Bob Johnson";
    },

    // Exercise 448
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard Logitech", "price": 250000},
        {"id": 2, "name": "Mouse Logitech", "price": 150000},
        {"id": 3, "name": "Headphones Sony", "price": 350000},
      ];
      List<Map<String, dynamic>> matchedProducts = [];

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan nama mengandung huruf "Sony"
      // atau mengandung huruf "Logi"
      // Kemudian masukkan data produk tersebut ke dalam list matchedProducts
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedProducts.length == 3;
    },

    // Exercise 449
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard Logitech", "price": 250000},
        {"id": 2, "name": "Mouse Logitech", "price": 150000},
        {"id": 3, "name": "Headphones Sony", "price": 350000},
      ];
      List<Map<String, dynamic>> matchedProducts = [];

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan harga kurang dari 200000
      // atau mengandung huruf "Sony" dalam nama produk
      // Kemudian masukkan data produk tersebut ke dalam list matchedProducts
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedProducts.length == 2;
    },

    // Exercise 451
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John Doe", "age": 28},
        {"id": 2, "name": "Alice Smith", "age": 32},
        {"id": 3, "name": "Bob Johnson", "age": 25},
      ];
      List<Map<String, dynamic>> matchedEmployees = [];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan dengan usia lebih dari 35 tahun
      // atau nama mengandung huruf "Smith"
      // Kemudian masukkan data karyawan tersebut ke dalam list matchedEmployees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedEmployees.length == 1 &&
          matchedEmployees[0]["name"] == "Alice Smith";
    },

    // Exercise 452
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard Logitech", "price": 250000},
        {"id": 2, "name": "Mouse Logitech", "price": 150000},
        {"id": 3, "name": "Headphones Sony", "price": 350000},
      ];
      List<Map<String, dynamic>> matchedProducts = [];

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan harga lebih dari 300000
      // atau nama mengandung huruf "Sony" dalam produk
      // Kemudian masukkan data produk tersebut ke dalam list matchedProducts
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedProducts.length == 1 &&
          matchedProducts[0]["name"] == "Headphones Sony";
    },

    // Exercise 453
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John Doe", "age": 28},
        {"id": 2, "name": "Alice Smith", "age": 32},
        {"id": 3, "name": "Bob Johnson", "age": 25},
      ];
      List<Map<String, dynamic>> matchedEmployees = [];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan dengan usia di antara 25 dan 30 tahun (inklusif)
      // atau nama depan mengandung huruf "Bob"
      // Kemudian masukkan data karyawan tersebut ke dalam list matchedEmployees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedEmployees.length == 2 &&
          matchedEmployees[0]["name"] == "John Doe" &&
          matchedEmployees[1]["name"] == "Bob Johnson";
    },

    // Exercise 454
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard Logitech", "price": 250000},
        {"id": 2, "name": "Mouse Logitech", "price": 150000},
        {"id": 3, "name": "Headphones Sony", "price": 350000},
      ];
      List<Map<String, dynamic>> matchedProducts = [];

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan harga kurang dari 200000
      // dan nama produk mengandung huruf "og"
      // Kemudian masukkan data produk tersebut ke dalam list matchedProducts
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedProducts.length == 1 &&
          matchedProducts[0]["name"] == "Mouse Logitech";
    },

    // Exercise 455
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John Doe", "age": 28},
        {"id": 2, "name": "Alice Smith", "age": 32},
        {"id": 3, "name": "Bob Johnson", "age": 25},
      ];
      List<Map<String, dynamic>> matchedEmployees = [];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan dengan usia kurang dari 30 tahun
      // dan nama belakang mengandung huruf "son"
      // Kemudian masukkan data karyawan tersebut ke dalam list matchedEmployees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedEmployees.length == 1 &&
          matchedEmployees[0]["name"] == "Bob Johnson";
    },

    // Exercise 456
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John Doe", "age": 36},
        {"id": 2, "name": "Alice Smith", "age": 44},
        {"id": 3, "name": "Bob Johnson", "age": 25},
      ];
      List<Map<String, dynamic>> matchedEmployees = [];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan dengan usia lebih dari 35 tahun
      // dan nama mengandung huruf "Smith"
      // Kemudian masukkan data karyawan tersebut ke dalam list matchedEmployees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedEmployees.isNotEmpty && matchedEmployees.first["id"] == 2;
    },

    // Exercise 457
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard Logitech", "price": 250000},
        {"id": 2, "name": "Mouse Logitech", "price": 150000},
        {"id": 3, "name": "Headphones Sony", "price": 350000},
      ];
      List<Map<String, dynamic>> matchedProducts = [];

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan harga lebih dari 300000
      // dan nama mengandung huruf "Sony" dalam produk
      // Kemudian masukkan data produk tersebut ke dalam list matchedProducts
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedProducts.length == 1 &&
          matchedProducts[0]["name"] == "Headphones Sony";
    },

    // Exercise 458
    () {
      List<Map<String, dynamic>> employees = [
        {"id": 1, "name": "John Doe", "age": 28},
        {"id": 2, "name": "Alice Smith", "age": 32},
        {"id": 3, "name": "Bob Johnson", "age": 25},
      ];
      List<Map<String, dynamic>> matchedEmployees = [];

      // ? Instruksi: Gunakan looping for untuk mencari karyawan dengan usia di antara 25 dan 30 tahun (inklusif)
      // dan nama depan mengandung huruf "Bob"
      // Kemudian masukkan data karyawan tersebut ke dalam list matchedEmployees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedEmployees.length == 1 &&
          matchedEmployees[0]["name"] == "Bob Johnson";
    },

    // Exercise 459
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Keyboard Logitech", "price": 250000},
        {"id": 2, "name": "Mouse Logitech", "price": 150000},
        {"id": 3, "name": "Headphones Sony", "price": 350000},
      ];
      List<Map<String, dynamic>> matchedProducts = [];

      // ? Instruksi: Gunakan looping for untuk mencari produk dengan harga kurang dari 200000
      // dan nama produk mengandung huruf "og"
      // Kemudian masukkan data produk tersebut ke dalam list matchedProducts
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return matchedProducts.length == 1 &&
          matchedProducts[0]["name"] == "Mouse Logitech";
    },

    // Exercise 460
    () {
      List<Map<String, dynamic>> orders = [
        {"id": 1, "product": "Phone", "quantity": 2, "total": 1000},
        {"id": 2, "product": "Laptop", "quantity": 1, "total": 1200},
        {"id": 3, "product": "Headphones", "quantity": 3, "total": 150},
        {"id": 4, "product": "TV", "quantity": 1, "total": 800},
      ];
      int index = -1;

      // ? Instruksi: Gunakan looping for untuk mencari index dari order dengan id 3 dalam list orders
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return index == 2;
    },

    // Exercise 461
    () {
      List<Map<String, dynamic>> employees = [
        {"name": "John", "age": 30, "department": "Sales", "salary": 5000},
        {"name": "Alice", "age": 28, "department": "IT", "salary": 6000},
        {"name": "Bob", "age": 35, "department": "HR", "salary": 4500},
        {"name": "Eva", "age": 40, "department": "Finance", "salary": 7000},
      ];
      int index = -1;

      // ? Instruksi: Gunakan looping for untuk mencari index dari employee dengan name "Eva" dan salary lebih dari 6000 dalam list employees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---
      return index == 3;
    },

    // Exercise 462
    () {
      List<Map<String, dynamic>> transactions = [
        {"id": 1, "type": "Sale", "amount": 100, "status": "Completed"},
        {"id": 2, "type": "Purchase", "amount": 50, "status": "Completed"},
        {"id": 3, "type": "Refund", "amount": 25, "status": "Pending"},
        {"id": 4, "type": "Sale", "amount": 75, "status": "Completed"},
        {"id": 5, "type": "Purchase", "amount": 30, "status": "Pending"},
      ];
      int index = -1;

      // ? Instruksi: Gunakan looping for untuk mencari index dari transaction dengan id 5 dan type "Purchase" dalam list transactions
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return index == 4;
    },

    // Exercise 463
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Phone", "price": 500},
        {"id": 2, "name": "Laptop", "price": 1200},
        {"id": 3, "name": "Headphones", "price": 50},
        {"id": 4, "name": "TV", "price": 800},
      ];
      int index = -1;

      // ? Instruksi: Gunakan looping for untuk mencari index dari product dengan id 2 dan price 1200 dalam list products
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return index == 1;
    },

    // Exercise 464
    () {
      List<Map<String, dynamic>> employees = [
        {"name": "John", "age": 30, "department": "Sales", "salary": 5000},
        {"name": "Alice", "age": 28, "department": "IT", "salary": 6000},
        {"name": "Bob", "age": 35, "department": "HR", "salary": 4500},
        {"name": "Eva", "age": 40, "department": "Finance", "salary": 7000},
      ];
      int index = -1;

      // ? Instruksi: Gunakan looping for untuk mencari index dari employee dengan name "Bob" dan age lebih dari 30 dalam list employees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return index == 2;
    },

    // Exercise 465
    () {
      List<Map<String, dynamic>> transactions = [
        {"id": 1, "type": "Sale", "amount": 100, "status": "Completed"},
        {"id": 2, "type": "Purchase", "amount": 50, "status": "Completed"},
        {"id": 3, "type": "Refund", "amount": 25, "status": "Pending"},
        {"id": 4, "type": "Sale", "amount": 75, "status": "Completed"},
        {"id": 5, "type": "Purchase", "amount": 30, "status": "Pending"},
      ];
      int index = -1;

      // ? Instruksi: Gunakan looping for untuk mencari index dari transaction dengan type "Refund" dan status "Pending" dalam list transactions
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return index == 2;
    },

    // Exercise 466
    () {
      List<Map<String, dynamic>> products = [
        {"id": 1, "name": "Phone", "price": 500, "stock": 10},
        {"id": 2, "name": "Laptop", "price": 1200, "stock": 5},
        {"id": 3, "name": "Headphones", "price": 50, "stock": 20},
        {"id": 4, "name": "TV", "price": 800, "stock": 15},
      ];
      int index = -1;

      // ? Instruksi: Gunakan looping for untuk mencari index dari product dengan name "Headphones" dan stock lebih dari 15 dalam list products
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---
      return index == 2;
    },

    // Exercise 467
    () {
      List<Map<String, dynamic>> employees = [
        {"name": "John", "age": 30, "department": "Sales", "salary": 5000},
        {"name": "Alice", "age": 28, "department": "IT", "salary": 6000},
        {"name": "Bob", "age": 35, "department": "HR", "salary": 4500},
        {"name": "Eva", "age": 40, "department": "Finance", "salary": 7000},
      ];
      int index = -1;

      // ? Instruksi: Gunakan looping for untuk mencari index dari employee dengan name "John", age 30, dan department "Sales" dalam list employees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return index == 0;
    },

    // Exercise 468
    () {
      List<Map<String, dynamic>> transactions = [
        {"id": 1, "type": "Sale", "amount": 100, "status": "Completed"},
        {"id": 2, "type": "Purchase", "amount": 50, "status": "Completed"},
        {"id": 3, "type": "Refund", "amount": 25, "status": "Pending"},
        {"id": 4, "type": "Sale", "amount": 75, "status": "Completed"},
        {"id": 5, "type": "Purchase", "amount": 30, "status": "Pending"},
      ];
      int index = -1;

      // ? Instruksi: Gunakan looping for untuk mencari index dari transaction dengan amount 75 dan status "Completed" dalam list transactions
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return index == 3;
    },

    // Exercise 469
    () {
      List<Map<String, dynamic>> users = [
        {
          "id": 1,
          "name": "John",
          "age": 25,
          "gender": "Male",
          "email": "john@example.com",
          "city": "New York",
          "country": "USA",
          "isSubscribed": true,
          "isVerified": true,
          "isAdmin": false
        },
        {
          "id": 2,
          "name": "Alice",
          "age": 30,
          "gender": "Female",
          "email": "alice@example.com",
          "city": "Los Angeles",
          "country": "USA",
          "isSubscribed": true,
          "isVerified": false,
          "isAdmin": false
        },
        {
          "id": 3,
          "name": "Bob",
          "age": 22,
          "gender": "Male",
          "email": "bob@example.com",
          "city": "Chicago",
          "country": "USA",
          "isSubscribed": true,
          "isVerified": true,
          "isAdmin": false
        },
        {
          "id": 4,
          "name": "Eva",
          "age": 28,
          "gender": "Female",
          "email": "eva@example.com",
          "city": "New York",
          "country": "USA",
          "isSubscribed": true,
          "isVerified": true,
          "isAdmin": true
        },
      ];
      List<Map<String, dynamic>> subscribedUsers = [];

      // Instruksi: Gunakan looping for untuk mencari user yang berlangganan (isSubscribed = true), telah diverifikasi (isVerified = true),
      // memiliki gender "Female", berusia di atas 25 tahun, dan tinggal di kota "Los Angeles" atau "New York"
      // Masukkan user yang memenuhi kriteria tersebut ke dalam list subscribedUsers
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---
      return subscribedUsers.isNotEmpty && subscribedUsers.first["id"] == 4;
    },

    // Exercise 470
    () {
      List<Map<String, dynamic>> products = [
        {
          "id": 1,
          "name": "Phone",
          "price": 500,
          "stock": 10,
          "category": "Electronics",
          "brand": "Apple",
          "isAvailable": true,
          "isFeatured": true,
          "rating": 4.5,
          "reviews": 100
        },
        {
          "id": 2,
          "name": "Laptop",
          "price": 1200,
          "stock": 5,
          "category": "Electronics",
          "brand": "Dell",
          "isAvailable": true,
          "isFeatured": false,
          "rating": 4.2,
          "reviews": 50
        },
        {
          "id": 3,
          "name": "Headphones",
          "price": 50,
          "stock": 20,
          "category": "Electronics",
          "brand": "Sony",
          "isAvailable": true,
          "isFeatured": true,
          "rating": 4.7,
          "reviews": 200
        },
        {
          "id": 4,
          "name": "TV",
          "price": 800,
          "stock": 15,
          "category": "Electronics",
          "brand": "Samsung",
          "isAvailable": true,
          "isFeatured": true,
          "rating": 4.8,
          "reviews": 300
        },
      ];
      List<Map<String, dynamic>> featuredProducts = [];

      // Instruksi: Gunakan looping for untuk mencari product yang merupakan produk unggulan (isFeatured = true),
      // memiliki rating di atas 4.5, tersedia (isAvailable = true), dan memiliki lebih dari 100 ulasan (reviews > 100)
      // Masukkan product yang memenuhi kriteria tersebut ke dalam list featuredProducts
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return featuredProducts.length == 2 &&
          featuredProducts[0]["name"] == "Headphones" &&
          featuredProducts[1]["name"] == "TV";
    },

    // Exercise 471
    () {
      List<Map<String, dynamic>> employees = [
        {
          "id": 1,
          "name": "John",
          "age": 30,
          "department": "Sales",
          "salary": 5000,
          "position": "Manager",
          "yearsOfExperience": 5,
          "isPermanent": true,
          "isFullTime": true,
          "hasHealthInsurance": true
        },
        {
          "id": 2,
          "name": "Alice",
          "age": 25,
          "department": "IT",
          "salary": 6000,
          "position": "Engineer",
          "yearsOfExperience": 3,
          "isPermanent": true,
          "isFullTime": true,
          "hasHealthInsurance": true
        },
        {
          "id": 3,
          "name": "Bob",
          "age": 28,
          "department": "Finance",
          "salary": 4500,
          "position": "Analyst",
          "yearsOfExperience": 4,
          "isPermanent": true,
          "isFullTime": true,
          "hasHealthInsurance": false
        },
        {
          "id": 4,
          "name": "Eva",
          "age": 27,
          "department": "IT",
          "salary": 7500,
          "position": "Associate",
          "yearsOfExperience": 4,
          "isPermanent": false,
          "isFullTime": true,
          "hasHealthInsurance": false
        },
      ];
      List<Map<String, dynamic>> highPaidEmployees = [];

      // Instruksi: Gunakan looping for untuk mencari karyawan dengan gaji tinggi (salary > 5000),
      // berusia di atas 25 tahun, memiliki pengalaman kerja lebih dari 3 tahun (yearsOfExperience > 3),
      // dan bekerja di departemen "IT" atau "Finance"
      // Masukkan karyawan yang memenuhi kriteria tersebut ke dalam list highPaidEmployees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return highPaidEmployees.isNotEmpty && highPaidEmployees.first["id"] == 4;
    },

    // Exercise 472
    () {
      List<Map<String, dynamic>> employees = [
        {
          "id": 1,
          "name": "John",
          "age": 30,
          "department": "Sales",
          "salary": 5000,
          "position": "Manager",
          "yearsOfExperience": 5,
          "isPermanent": true,
          "isFullTime": true,
          "hasHealthInsurance": true
        },
        {
          "id": 2,
          "name": "Alice",
          "age": 25,
          "department": "IT",
          "salary": 6000,
          "position": "Engineer",
          "yearsOfExperience": 3,
          "isPermanent": true,
          "isFullTime": true,
          "hasHealthInsurance": true
        },
        {
          "id": 3,
          "name": "Bob",
          "age": 28,
          "department": "Finance",
          "salary": 4500,
          "position": "Analyst",
          "yearsOfExperience": 4,
          "isPermanent": true,
          "isFullTime": true,
          "hasHealthInsurance": false
        },
        {
          "id": 4,
          "name": "Eva",
          "age": 22,
          "department": "Sales",
          "salary": 3500,
          "position": "Associate",
          "yearsOfExperience": 1,
          "isPermanent": false,
          "isFullTime": false,
          "hasHealthInsurance": false
        },
      ];
      List<Map<String, dynamic>> partTimeEmployees = [];

      // Instruksi: Gunakan looping for untuk mencari karyawan dengan status paruh waktu (isFullTime = false),
      // tidak memiliki asuransi kesehatan (hasHealthInsurance = false),
      // dan berusia di bawah 25 tahun (age < 25)
      // Masukkan karyawan yang memenuhi kriteria tersebut ke dalam list partTimeEmployees
      // >>> Tulis kode for loop di sini

      // --- End of Answer ---

      return partTimeEmployees.isNotEmpty && partTimeEmployees.first["id"] == 4;
    },
  ];
}
